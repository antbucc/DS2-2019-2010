package lPBCast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import repast.simphony.random.RandomHelper;
import repast.simphony.util.SimUtilities;

public class Utilities {
	
	private static Utilities instance;	
	private int ID_EVENT = 0;

	/**
	 * Given a set it extract a random subset of a given size
	 * @param <T> The class type of the items
	 * @param source The input of the process
	 * @param size The size (bounded between 0, |source|)
	 * @return A smaller/equal subset
	 */
	public static <T> HashSet<T> getRandomSubset(Set<T> source, int size){
		
		// Adjust size in case of OutOf Bound
		size = Math.max(0, size);
		size = Math.min(size, source.size());
		
		// Convert the set into a list
		ArrayList<T> list = new ArrayList<T>();
		for(T item : source) {
			list.add(item);
		}
		
		return getRandomSubset(list, size);
		
	}

	/**
	 * Given a list it extract a random set with a given size
	 * @param <T> The class type of the items
	 * @param source The input of the process
	 * @param size The size (bounded between 0, |source|)
	 * @return A smaller/equal subset
	 */
	public static <T> HashSet<T> getRandomSubset(List<T> source, int size){
		
		// Adjust size in case of OutOf Bound
		size = Math.max(0, size);
		size = Math.min(size, source.size());
		
		// Shuffle the list
		if (source.size() != size) {
			SimUtilities.shuffle(source, RandomHelper.getUniform());
		}
		
		// Select the first "size" items
		HashSet<T> result = new HashSet<T>();
		for(int i = 0; i < size; i++) {
			result.add(source.get(i));
		}
		
		return result;
		
	}
	
	/**
	 * Method used for beautify the print of the set
	 * If it is a set of nodes, print their identifier, otherwise use the usual toString()
	 * @param <T> The class type of the items in the set
	 * @param set The set to be printed
	 * @return The output as a string
	 */
	public static <T> String printSet(HashSet<T> set) {
		// If there is something
		if(set.size() > 0) {
			String out = "";
			for(T item : set) {
				if(item instanceof Node) {
					// Add the dentifier to the output string
					out += ((Node) item).getIdentifier();
				}
				else {
					out += item.toString();
				}
				// Add a separator
				out += ", ";
			}
			// Remove the last useless separator
			return out.substring(0, out.length() - 2);
		}
		else {
			return "|EMPTY SET|";
		}
	}

	public static <T> String printList(ArrayList<T> list) {
		// If there is something
		if(list.size() > 0) {
			String out = "";
			for(T item : list) {
				if(item instanceof Node) {
					// Add the dentifier to the output string
					out += ((Node) item).getIdentifier();
				}
				else {
					out += item.toString();
				}
				// Add a separator
				out += ", ";
			}
			// Remove the last useless separator
			return out.substring(0, out.length() - 2);
		}
		else {
			return "|EMPTY LIST|";
		}
	}
	
	public static Utilities getInstance() {
		if(instance == null) {
			instance = new Utilities();
		}
		return instance;
	}
	
	public int getIDEvent() {
		return ID_EVENT++;
	}
	
}
