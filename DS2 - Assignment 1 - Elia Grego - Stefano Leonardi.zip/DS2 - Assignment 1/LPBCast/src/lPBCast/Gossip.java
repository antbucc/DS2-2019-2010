package lPBCast;

import java.util.ArrayList;
import java.util.HashSet;

// Class representing a message in the protocol
public class Gossip {

	private HashSet<Node> subs = new HashSet<Node>(); 
	private HashSet<Node> unsubs = new HashSet<Node>();
	private ArrayList<Event<String>> events;
	private ArrayList<EventId> eventIds;

	// Constructor
	public Gossip(HashSet<Node> subs, HashSet<Node> unsubs, ArrayList<Event<String>> events, ArrayList<EventId> eventsIds) {
		// It just copies the variables
		this.subs = subs;
		this.unsubs = unsubs;
		this.events = events;
		this.eventIds = eventsIds;
	}
	
	// Getter
	public ArrayList<EventId> getEventIds() {
		return this.eventIds;
	}	
	public ArrayList<Event<String>> getEvents() {
		return this.events;
	}	
	public HashSet<Node> getSubs() {
		return this.subs;
	}	
	public HashSet<Node> getUnsubs() {
		return this.unsubs;
	}
	
	public Gossip copy() {
		
		HashSet<Node> newSubs = new HashSet<Node>();
		for(Node node : this.subs) {
			newSubs.add(node);
		}
		
		HashSet<Node> newUnsubs = new HashSet<Node>();
		for(Node node : this.unsubs) {
			newUnsubs.add(node);
		}
		
		ArrayList<Event<String>> newEvents = new ArrayList<Event<String>>();
		for(Event<String> e : this.events) {
			newEvents.add(e.copy());
		}
		
		ArrayList<EventId> newEventIds = new ArrayList<EventId>();
		for(EventId eid : this.eventIds) {
			newEventIds.add(eid.copy());
		}
		
		return new Gossip(newSubs, newUnsubs, newEvents, newEventIds);
		
	}
	
}
