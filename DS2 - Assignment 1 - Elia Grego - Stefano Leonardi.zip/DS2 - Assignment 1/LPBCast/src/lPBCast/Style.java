package lPBCast;

import java.awt.Color;
import java.awt.Font;

import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import repast.simphony.visualizationOGL2D.StyleOGL2D;

@SuppressWarnings("rawtypes")
public class Style extends DefaultStyleOGL2D implements StyleOGL2D {

	@Override
	public Color getColor(Object agent) {
		if (agent instanceof Node) {
			Node node = (Node) agent;
			if(node.getState() == Node.SUBSCRIBER) {
				return Color.BLACK;
			}
			else if(node.getState() == Node.UNSUBSCRIBER) {
				return Color.RED;
			}
		}
		return super.getColor(agent);
	}
	
	@Override
	public Font getLabelFont(Object object) {
		return new Font("Calibri", Font.PLAIN, 16);
	}
	
	@Override
	public float getLabelYOffset(Object object) {
		return 5;
	}

	@Override
	public String getLabel(Object agent) {
		if (agent instanceof Node) {
			Node node = (Node) agent;
			return node.getLabel();
		}
		return super.getLabel(agent);
	}

}
