package lPBCast;

import java.util.ArrayList;

import repast.simphony.context.Context;
import repast.simphony.context.space.continuous.ContinuousSpaceFactory;
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder;
import repast.simphony.context.space.graph.NetworkBuilder;
import repast.simphony.context.space.grid.GridFactory;
import repast.simphony.context.space.grid.GridFactoryFinder;
import repast.simphony.dataLoader.ContextBuilder;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.continuous.RandomCartesianAdder;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridBuilderParameters;
import repast.simphony.space.grid.SimpleGridAdder;
import repast.simphony.space.grid.WrapAroundBorders;

public class NodeBuilders implements ContextBuilder<Object> {

	// Local variables, they are got from the runtime parameters
	private int numberOfNodes;
	private int numberOfSubscribers;
	@SuppressWarnings("unused")
	private int fanoutSize;
	@SuppressWarnings("unused")
	
	@Override
	public Context<Object> build(Context<Object> context) {		
	
		NetworkBuilder<Object> netBuilder = new NetworkBuilder<Object>("messages", context, true);
		netBuilder.buildNetwork();
		
		context.setId("LPBCast");

		// Create the space and the grid
		// The references "space" and "grid" are in the context.xml file
		ContinuousSpaceFactory spaceFactory = ContinuousSpaceFactoryFinder.createContinuousSpaceFactory(null);
		ContinuousSpace<Object> space = spaceFactory.createContinuousSpace("space", context, new RandomCartesianAdder<Object>(), new repast.simphony.space.continuous.WrapAroundBorders(), 50, 50);
		GridFactory gridFactory = GridFactoryFinder.createGridFactory(null);
		Grid<Object> grid = gridFactory.createGrid("grid", context, new GridBuilderParameters<Object>(new WrapAroundBorders(), new SimpleGridAdder<Object>(), true, 50, 50));
		
		// Set the number of nodes (n) and the number of subscribers, at least one, minimum the 20% of all the nodes
		Parameters params = RunEnvironment.getInstance().getParameters();
		this.numberOfNodes = params.getInteger("nodes");	
		this.numberOfNodes = Math.max(1, this.numberOfNodes);
		
		// Bound 1 <= minSubscribers <= #nodes 
		int minSubscribers = params.getInteger("min_subs");
		minSubscribers = Math.max(2, minSubscribers);
		minSubscribers = Math.min(this.numberOfNodes, minSubscribers);		
		
		// Bound 1 <= fanoutSize <= minSubscribers
		int fanoutSize = params.getInteger("fanout");
		fanoutSize = Math.max(1, fanoutSize);
		fanoutSize = Math.min(minSubscribers, fanoutSize);		
		
		this.numberOfSubscribers = RandomHelper.nextIntFromTo(Math.max((int)(numberOfNodes*0.2), minSubscribers), numberOfNodes);
		
		// I prepare the list containing all the nodes
		// And for each one, we initialise it and we add it to the context
		ArrayList<Node> nodes = new ArrayList<Node>();				
		for (int i = 0; i < numberOfNodes; i++) {	
			Node n = new Node(i, space, grid, context);
			nodes.add(n);
			context.add(n);
		}

		// Here I create two different lists, one for the subscribers and one for the unsubscribers
		ArrayList<Node> subscribers = new ArrayList<Node>();
		ArrayList<Node> unsubscribers = new ArrayList<Node>();

		// We shuffle the array in order to make the algorithm as realistic as possible
		//SimUtilities.shuffle(nodes, RandomHelper.getUniform());
		
		// For 0 < i < numberOfSubscribers (add numberOfSubscribers nodes to the subs array)
		int i = 0;
		for(; i < numberOfSubscribers; i++) {
			subscribers.add(nodes.get(i));
		}
		// For numberOfSubscribers <= i < numberOfNodes (add the other nodes to the unsubs array)
		for(; i < numberOfNodes; i++) {
			unsubscribers.add(nodes.get(i));
		}
				
		// For each object into the continuous space, update also the cell onto the grid in which the object is located
		for (Object obj : context) {
			NdPoint pt = space.getLocation(obj);
			grid.moveTo(obj, (int)pt.getX(), (int)pt.getY());
		}

		// Just some print for seeing what is going on
		System.out.println("nodes = " + numberOfNodes);
		System.out.println("sub_size = " + subscribers.size());
		System.out.println("unsub_size = " + unsubscribers.size());	
		
		// At the beginning, every node knows ALL the subscribers
		// Anyway, the network can change continuously, so it dynamically will adapt itself to joins/leaves whenever they occur.
		// We can also make this process random by passing a (every time) random subset of subscribers to every node
		// i is the unique identifier of each node
		i = 0;
		for(Node node : nodes) {
			node.setSubsAndUnsub(subscribers, unsubscribers, subscribers.contains(node), fanoutSize);
			i++;
		}
		
		return context;
		
	}	

}
