package lPBCast;

public class EventId {

	private int ID;
	private Node source;

	public EventId(int ID, Node source) {
		this.ID = ID;
		this.source = source;
	}

	// Getter
	public Node getSource() {
		return source;
	}

	public int getID() {
		return ID;
	}
	
	public EventId copy() {
		return new EventId(ID, source);
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof EventId) {
			EventId eid = (EventId)obj;
			return eid.getID() == this.getID();
		}
		return false;
	}
	
}
