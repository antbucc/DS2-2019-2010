package lPBCast;

public class Event<T> {

	private T content;

	// Also known as "Time to Live"
	private int age;
	private EventId eventID;

	public Event(T content, int age, EventId eventId) {
		this.content = content;
		this.age = age;
		this.eventID = eventId;
	}

	// Getter
	public int getAge() {
		return age;
	}

	public T getContent() {
		return content;
	}

	public EventId getEventID() {
		return eventID;
	}
	
	/**
	 * Decrease the age of a message
	 */
	public void decreaseAge() {
		if(this.age >= 1) {
			this.age--;
		}
		else {
			this.age = 0;
		}
	}
	
	public Event<T> copy(){
		return new Event<T>(this.content, this.age, this.eventID);
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Event) {
			Event<?> e = (Event<?>)obj;
			return e.content.equals(this.content) && this.eventID.equals(e.getContent());
		}
		return false;
	}
	
}
