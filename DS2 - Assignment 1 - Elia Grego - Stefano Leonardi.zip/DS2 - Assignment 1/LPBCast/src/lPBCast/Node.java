package lPBCast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.graph.Network;
import repast.simphony.space.grid.Grid;

public class Node {

	// ============================================================
	// App variables
	private HashSet<Event<String>> eventsAPP;

	// ============================================================
	// STATES - Graphical purpose only ----------------------------

	// Local state of the Node, used just for graphical purpose
	private int state;
	private String label;
	private int colorArc;

	// Possible states
	public static int SUBSCRIBER = 1;
	public static int UNSUBSCRIBER = 2;

	// End State ---------------------------------
	// ============================================================

	// Local variables
	private int identifier;
	private boolean amIASubscriber;
	private int fanoutSize;

	// Max size for the lists
	public static int SUBS_MAX = 100;
	public static int UNSUBS_MAX = 100;
	public static int VIEW_MAX = 100;
	public static int EVENTS_TO_KEEP = 100;

	// Repast variables
	@SuppressWarnings("unused")
	private ContinuousSpace<Object> space;
	private Grid<Object> grid;
	private int tick;

	// Local knowledge of a node
	private HashSet<Node> subs = new HashSet<Node>();
	private HashSet<Node> unsubs = new HashSet<Node>();
	private HashSet<Node> view = new HashSet<Node>();

	private ArrayList<Event<String>> events;
	private ArrayList<EventId> eventIds;	
	private ArrayList<Gossip> incomingGossips;
	private ArrayList<Node> incomingGossipsSender;
	private HashSet<EventId> missingEventsBuffer;
	private Network<Object> net;
	
	// Test variables
	private boolean messageTestReceived;
	private int retrieverMessages;
	private int eventsInNet;

	// Constructor, it just copies the variables
	@SuppressWarnings("unchecked")
	public Node(int id, ContinuousSpace<Object> space, Grid<Object> grid, Context<?> context) {
		this.space = space;
		this.grid = grid;
		this.events = new ArrayList<Event<String>>();
		this.eventIds = new ArrayList<EventId>();
		this.eventsAPP = new HashSet<Event<String>>();
		this.identifier = id;
		this.tick = 0;
		this.label = String.valueOf(id);
		this.messageTestReceived = false;
		this.incomingGossips = new ArrayList<Gossip>();
		this.incomingGossipsSender = new ArrayList<Node>();
		this.net = (Network<Object>) context.getProjection("messages");
		this.missingEventsBuffer = new HashSet<EventId>();
		this.retrieverMessages = 0;
		this.eventsInNet = 0;
	}

	/**
	 * This method sets the lists of subs and unsubs to the current node and create
	 * the view
	 * 
	 * @param id             The unique identifier of the node
	 * @param subscribers    The list of subs
	 * @param unsubscribers  The list of unsubs
	 * @param amIASubscriber It tells to the node whether it belongs to the subs set
	 *                       rather than the unsubs set
	 */
	public void setSubsAndUnsub(ArrayList<Node> subscribers, ArrayList<Node> unsubscribers, boolean amIASubscriber,	int fanoutSize) {

		// Copy the local variables to the class variables
		this.amIASubscriber = amIASubscriber;
		this.fanoutSize = fanoutSize;

		// Copy the subscribers to the set
		// So in this way we don't modify the subscribers list (being a pointer)
		for (Node sub : subscribers) {
			subs.add(sub);
		}

		// The same as before for the unsubs
		for (Node unsub : unsubscribers) {
			unsubs.add(unsub);
		}

		if (subscribers.size() >= 1) {

			// If there if more than one subscriber, I select a random number of them to be
			// part of the view
			// Note that this "subscribers" list is the local knowledge of the node
			// It is not necessary the same for all the nodes
			int viewSize = RandomHelper.nextIntFromTo(1, subscribers.size());

			// In order to avoid selecting myself as part of the view, I remove temporary
			// myself from the list
			// The method is executed sequentially, so I have no concurrency problem
			if (amIASubscriber) {
				subscribers.remove(this);
			}

			// Get a random subset of subscriber with size viewSize
			view = Utilities.getRandomSubset(subscribers, viewSize);

			// Re-add myself again to the list
			// In case subscribers is the same pointer for each node, I let unaltered the
			// list
			if (amIASubscriber) {
				subscribers.add(this);
			}

		}
		
		// Graphical purpose only
		if (amIASubscriber) {
			state = Node.SUBSCRIBER;
		} else {
			state = Node.UNSUBSCRIBER;
		}

		// System.out.println("[" + this.identifier + "]" + star + " My view set: " + Utilities.printSet(view));

	}

	@ScheduledMethod(start = 1, interval = 1)
	public void step() {
		
		if(this.identifier == 0 && this.tick%14 == 0) {
			this.net.removeEdges();
		}

		// Graphical purpose only
		clearLabel();
		
		// Get tick count
		this.tick = (int) RunEnvironment.getInstance().getCurrentSchedule().getTickCount();

		// Processing the sending of the messages (Odd ticks)
		if(this.tick%2 == 1) {
			
			// Simulate changes on the network topology
			boolean nodeBecameUnsub = simulateTopologyChanges();
	
			if (amIASubscriber || nodeBecameUnsub) {
	
				// Add event randomly to random node
				if (!nodeBecameUnsub) {
					generateEvents();
				}
	
				// ====================================================================================
				// ====================================================================================
	
				// Here starts the real GOSSIP EMISSION
	
				// The set of node subscribers to be sent is the set that I know + myself
				HashSet<Node> gossip_subs = new HashSet<Node>();
				for (Node subscriber : subs) {
					gossip_subs.add(subscriber);
				}
				if (!nodeBecameUnsub) {
					gossip_subs.add(this);
				}
	
				// The set to be sent of unsubscribers remain the same
				HashSet<Node> gossip_unsubs = new HashSet<Node>();
				for (Node unsubscriber : unsubs) {
					gossip_unsubs.add(unsubscriber);
				}					
					
				// Handling events
				ArrayList<Event<String>> gossip_events = new ArrayList<Event<String>>();	
				
				if(this.events.size() > 0 && !nodeBecameUnsub) {
					this.label = "S(" + this.identifier + "): ";
					for(Event<String> e : this.events) {
						gossip_events.add(e.copy());
						this.label += e.getContent().toString() + "|";
					}
				}
	
				// Handling eventIds
				ArrayList<EventId> gossip_eventIds = new ArrayList<EventId>();
				if(!nodeBecameUnsub) {
					for(EventId eId : this.eventIds) {
						gossip_eventIds.add(eId.copy());
					}
				}
	
				Gossip gossip = new Gossip(gossip_subs, gossip_unsubs, gossip_events, gossip_eventIds);
	
				// Select the fanout set and send the messages
				HashSet<Node> fanout;
				
				if(view.size() > 0) {				
					if (!nodeBecameUnsub) {
						fanout = Utilities.getRandomSubset(view, fanoutSize);
					} else {			
						// If you just unsubscribed, send the "notification" to all nodes into subs
						fanout = Utilities.getRandomSubset(subs, subs.size());
					}
				}
				else {
					// If you just subscribe and you have no node into your view, send the message to the unsubscribers
					// So they can discover your existance
					fanout = Utilities.getRandomSubset(unsubs, fanoutSize);
				}

				// TEST code
				//this.eventsInNet += this.events.size()*fanout.size();
				// END TEST code
				
				// System.out.println("[" + this.identifier + "] I am sending the gossip message to: " + recipients);
				for (Node recipient : fanout) {
					send(recipient, gossip.copy());
				}
	
				// Free memory
				gossip = null;
				System.gc();
										
				// Reset the events list
				this.events.clear();
				
			}
			
		}
		// Processing the reception of the messages (Even ticks)
		else if (amIASubscriber) {
			
			this.label += " ";
			// System.out.println("[" + identifier + "] Processing gossip...");	
							
			// Process all the gossips and fill the missingEventsBuffer set
			for(int i = 0; i < this.incomingGossips.size(); i++) {
				this.receive(incomingGossips.get(i), incomingGossipsSender.get(i));
			}
			
			this.incomingGossips.clear();
			this.incomingGossipsSender.clear();		
		
			// Process 
			ArrayList<EventId> tmpMissingBuffer = new ArrayList<EventId>();		
			for(EventId eventToBeRetrieved : missingEventsBuffer) {
				// If I have already got the event, remove its ID (logical remove)
				if(eventIds.contains(eventToBeRetrieved)) {
					tmpMissingBuffer.add(eventToBeRetrieved);
				}
				// Try to retrieve the event
				else {
					// Get the source of the message
					Node source = eventToBeRetrieved.getSource();
					if(source.getState() == Node.SUBSCRIBER) {					
						Event<String> retrievedEvent = source.retrieve(eventToBeRetrieved);					
						if(retrievedEvent != null) {
							// The sender got the event
							this.eventsInNet++;
							this.eventIds.add(retrievedEvent.getEventID());
							deliver(retrievedEvent, source);						
						}
						else {
							// Event not found, it was too old to keep
						}	
						tmpMissingBuffer.add(eventToBeRetrieved);
					}	
				}
			}

			// Physically remove the elements from the set
			for(EventId eid : tmpMissingBuffer) {
				missingEventsBuffer.remove(eid);
			}
							
			// System.out.println("     [" + identifier + "] UNSUBS:  " + Utilities.printSet(unsubs));
			// System.out.println("     [" + identifier + "] SUBS:    " + Utilities.printSet(subs));
			
		}

	}

	/**
	 * Send a lightweight probabilistic broadcast to the view
	 * 
	 * @param event The event to be sent
	 */
	public void lpbcast(String event) {

		// Get simulation parameters
		Parameters params = RunEnvironment.getInstance().getParameters();
		int age = params.getInteger("timetolive");
		age = Math.max(1, age);
		
		int id = Utilities.getInstance().getIDEvent();
		this.colorArc = id;
		
		EventId eid = new EventId(id, this);
		Event<String> ev = new Event<String>(event, age, eid);

		// Insert into the set of events to send
		this.events.add(ev);
		this.eventIds.add(eid);

		// Application data
		this.eventsAPP.add(ev);
		this.eventsAPP = Utilities.getRandomSubset(this.eventsAPP, Node.EVENTS_TO_KEEP);

		// System.out.println("\n[" + this.identifier + "] LPBCast(" + ev.getContent().toString() + ") with age: " + age);

	}

	/**
	 * It allows the node to send a message with a given probability of success
	 * given by the "probOfCommunicationSuccess" parameter of the simulation
	 * 
	 * @param recipient Who should receive the message
	 * @param gossip    The content of the message
	 */
	public void send(Node recipient, Gossip gossip) {

		// Get simulation parameters
		Parameters params = RunEnvironment.getInstance().getParameters();

		// Handle probability of unsubscription
		int randProbabilityOfUnsubscribtion = RandomHelper.nextIntFromTo(1, 1000);
		int probOfCommunicationSuccess = params.getInteger("probOfCommunicationSuccess");

		// Bound 0 - 1000
		probOfCommunicationSuccess = Math.min(1000, probOfCommunicationSuccess);
		probOfCommunicationSuccess = Math.max(0, probOfCommunicationSuccess);

		if (randProbabilityOfUnsubscribtion <= probOfCommunicationSuccess) {
			// Save the gossip on node to be processed later			
			recipient.getIncomingGossips().add(gossip);
			recipient.getIncomingGossipsSender().add(this);
		}

	}

	public void receive(Gossip gossip, Node sender) {

		// This if is needed! Consider the scenario in which a node change from sub to
		// unsub, and another
		// node has to communicate with the nodes into their view, it will send it also
		// to those node that
		// are not more a subscriber
		if (amIASubscriber) {

			// ##########################################################################################

			// Phase 1 - Update View and unSubs with unsubscription
			// ---------------------------------------------------------

			for (Node unsub : gossip.getUnsubs()) {
				this.view.remove(unsub);
				this.subs.remove(unsub);
				this.unsubs.add(unsub);
			}
			// Resize list
			unsubs = Utilities.getRandomSubset(unsubs, Node.UNSUBS_MAX);

			// End Phase 1 ---------------------------------------------

			// ##########################################################################################

			// Phase 2 - Update view with new subscription
			// ---------------------------------------------------------

			for (Node newSub : gossip.getSubs()) {
				if (newSub != this) {
					if (!this.view.contains(newSub)) {
						this.view.add(newSub);
						this.subs.add(newSub);
					}
				}
			}

			// Resize view list
			view = Utilities.getRandomSubset(view, Node.VIEW_MAX);

			// Resize subs set
			subs = Utilities.getRandomSubset(subs, Node.SUBS_MAX);

			// End Phase 2 ---------------------------------------------

			// ##########################################################################################

			// Extra phase ---------------------------------------------
			// There is a possibility that a node is at the same time in the subs and in the
			// unsubs sets
			// We give priority to the SUBS one

			unsubs.removeAll(subs);
			
			// END extra phase -----------------------------------------

			// ##########################################################################################

			// Phase 3 - Update events with new notifications
			// ---------------------------------------------------------
						
			// For each incoming Event
			for (Event<String> event : gossip.getEvents()) {
																
				// Check if not already received
				if (!eventIds.contains(event.getEventID())) {

					// Do something graphical
					// this.label = this.identifier + " - " + event;
					// This represent the deliver to the application
					deliver(event, sender);
					
					// Add the nodeId to the IDs
					this.eventIds.add(event.getEventID().copy());
					
					// I remove the ID because I have not to retrieve it later
					this.missingEventsBuffer.remove(event.getEventID());
					
					// Prepare the Event received for the next gossip step
					event.decreaseAge();
					if (event.getAge() > 0) {
						this.events.add(event.copy());
					}
				}
				// Else, do nothing, you already have the event

			}		
			
			// For each incoming EventId
			HashSet<EventId> missingEvents = new HashSet<EventId>();			
			for (EventId eId : gossip.getEventIds()) {
				if (!eventIds.contains(eId)) {
					missingEvents.add(eId);
				}
			}
			
			if(missingEvents.size() > 0) {			
				// System.out.println("[" + this.identifier + "] I have not received some events...");
				for(EventId eId : missingEvents) {
					// System.out.println("Event {" + eId.getID() + "}. I will retrieve it from " + eId.getSource().getIdentifier());
					// Add the missing events to a set.
					// I will retrieve them later (step method)
					boolean toAdd = true;
					for(EventId eid_tmp : missingEventsBuffer) {
						if(eid_tmp.getID() == eId.getID()) {
							toAdd = false;
							break;
						}
					}
					if(toAdd) {
						missingEventsBuffer.add(eId.copy());
					}					
				}
			}
 						
			// End Phase 3 ---------------------------------------------

			// ##########################################################################################
			
		}

	}

	// Simulation functions
	// =================================================================

	/**
	 * Simulate a random unsubscription/subscription according to the probability
	 * set on the simulation environment. It will remove/add itself from the set of
	 * local subscriber
	 * 
	 * @return true if node changed to UNSUB, false otherwise
	 */
	public boolean simulateTopologyChanges() {

		// Get simulation parameters
		Parameters params = RunEnvironment.getInstance().getParameters();

		// Handle probability of change
		int randProbabilityOfChangeTopology = RandomHelper.nextIntFromTo(1, 1000);
		int probOfChangeTopology = params.getInteger("probOfChangeTopology");

		// Bound 0 - 1000
		probOfChangeTopology = Math.min(1000, probOfChangeTopology);
		probOfChangeTopology = Math.max(0, probOfChangeTopology);

		if (randProbabilityOfChangeTopology <= probOfChangeTopology) {
			if (amIASubscriber) {
				subs.remove(this);
				// view.remove(this);
				// Useless, this node shoud not be here
				unsubs.add(this);
				setAsUnsubscribed();
				// System.out.println("\n==================================================================");
				// System.out.println("Node [" + this.identifier + "] changed to UNSUB");
				// System.out.println("==================================================================");
				return true;
			} else {
				subs.add(this);
				unsubs.remove(this);
				setAsSubscribed();
				// System.out.println("\n==================================================================");
				// System.out.println("Node [" + this.identifier + "] changed to SUB");
				// System.out.println("==================================================================");
				return false;
			}
		}
		return false;
	}

	public void generateEvents() {
		
		// TEST
		/*
		if(this.tick == 1 && this.identifier == 1) {
			// Simulate event
			lpbcast("Test_ONE");
			messageTestReceived = true;
		}
		*/
		// End test
				
		// Get simulation parameters
		Parameters params = RunEnvironment.getInstance().getParameters();
		
		int maxEventsGeneration = params.getInteger("maxEventsGeneration");
		maxEventsGeneration = Math.max(0, maxEventsGeneration);

		int probabilityOfGenerateAnEvent = (int) (params.getInteger("probabilityOfGenerateAnEvent")	/ maxEventsGeneration);

		// Bound 0 - 1000
		probabilityOfGenerateAnEvent = Math.min(1000, probabilityOfGenerateAnEvent);
		probabilityOfGenerateAnEvent = Math.max(0, probabilityOfGenerateAnEvent);
		

		// For maxEventsGeneration times, try to generate an event
		for (int round = 0; round < maxEventsGeneration; round++) {

			// Handle probability of generate an event
			int randProbabilityOfGenerateAnEvent = RandomHelper.nextIntFromTo(1, 1000);

			if (randProbabilityOfGenerateAnEvent <= probabilityOfGenerateAnEvent) {

				// Generate a random string as an EVENT
				int leftLimit = 97; // letter 'a'
				int rightLimit = 122; // letter 'z'
				int targetStringLength = 2;
				Random random = new Random();
				StringBuilder buffer = new StringBuilder(targetStringLength);
				for (int i = 0; i < targetStringLength; i++) {
					int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
					buffer.append((char) randomLimitedInt);
				}

				String event = buffer.toString().toUpperCase();

				// Lightweight Broadcast to the buffer
				lpbcast(event);

			}

		}

	}

	public Event<String> retrieve(EventId eId) {
		for(Event<String> e : this.eventsAPP) {
			if(e.getEventID().getID() == eId.getID()) {
				this.retrieverMessages++;
				return e;
			}
		}
		return null;
	}

	// Simulation functions
	// =================================================================

	// GETs
	// =================================================================================

	// Get the local identifier of a node
	public int getIdentifier() {
		return identifier;
	}

	// Graphical purpose only
	public int getState() {
		return state;
	}
	
	public void clearLabel() {
		this.label = String.valueOf(this.identifier);
	}

	/**
	 * You can change the colour or the style of a node with this method For the
	 * list of the possible states, look at the beginning of this class
	 * 
	 * @param state The new state of the agent Node
	 */
	public void setState(int state) {
		this.state = state;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getLabel() {
		return this.label;
	}

	// Get the subscribers and unsubscribers set
	public HashSet<Node> getSubs() {
		return subs;
	}

	public HashSet<Node> getUnsubs() {
		return unsubs;
	}

	public ArrayList<Gossip> getIncomingGossips() {
		return incomingGossips;
	}
	
	public ArrayList<Node> getIncomingGossipsSender() {
		return incomingGossipsSender;
	}
	
	public int getColorArc() {
		return colorArc;
	}
	
	public boolean isSubscriber() {
		return amIASubscriber;
	}

	// END GETs
	// =============================================================================

	// Support function
	// =====================================================================

	// Change the state of a node, from subscriber to unsubscriber
	public boolean setAsUnsubscribed() {
		if (amIASubscriber) {
			amIASubscriber = false;
			state = Node.UNSUBSCRIBER;
			return true;
		}
		return false;
	}

	// Change the state of a node, from unsubscriber to subscriber
	public boolean setAsSubscribed() {
		if (!amIASubscriber) {
			amIASubscriber = true;
			state = Node.SUBSCRIBER;
			return true;
		}
		return false;
	}

	// Query for the data-set and used in the plot during the simulation
	public int nodeSubscribed() {
		if (amIASubscriber) {
			return 1;
		}
		return 0;
	}
	
	public void deliver(Event<String> event, Node sender) {
		/*
		if(event.getContent().equals("Test_ONE")) {
			this.messageTestReceived = true;
		}
		*/
		this.label += event.getContent().toString() + "|";
		this.colorArc = event.getEventID().getID();
		net.addEdge(new MyEdge(sender, this, event));
	}
	
	public int testMsgReceived() {
		if(this.messageTestReceived) {
			return 1;
		}
		else {
			return 0;
		}
	}
		
	public int getRetrieverMessages() {
		return retrieverMessages;
	}
	
	public int getEventsInNet() {
		return eventsInNet;
	}	
	
	// END Support function
	// =================================================================

}
