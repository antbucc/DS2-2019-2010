package lPBCast;

import java.awt.Color;

import repast.simphony.space.graph.RepastEdge;
import repast.simphony.visualizationOGL2D.EdgeStyleOGL2D;

public class ArcStyle implements EdgeStyleOGL2D {
	
	@Override
	public int getLineWidth(RepastEdge<?> edge) {
		return 1;
	}

	@Override
	public Color getColor(RepastEdge<?> edge) {
		MyEdge myedge = (MyEdge)edge;
		int color = myedge.getEvent().getEventID().getID()%6;
		switch (color) {
			case 0:	return Color.RED;
			case 1:	return Color.GREEN;
			case 2:	return Color.BLUE;
			case 3:	return Color.MAGENTA;
			case 4:	return Color.ORANGE;
			default: return Color.CYAN;
		}
	}

}
