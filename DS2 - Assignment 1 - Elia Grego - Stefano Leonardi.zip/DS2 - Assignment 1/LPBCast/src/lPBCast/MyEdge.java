package lPBCast;

import repast.simphony.space.graph.RepastEdge;

public class MyEdge extends RepastEdge<Object> {
	
	private Event<String> event;
	
	public MyEdge(Node source, Node target, Event<String> event) {
		super(source, target, true);
		this.event = event;		
	}
	
	public Event<String> getEvent() {
		return event;
	}

}
