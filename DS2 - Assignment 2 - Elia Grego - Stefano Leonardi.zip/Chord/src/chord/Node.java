package chord;

import java.util.ArrayList;
import java.util.HashSet;

import com.fasterxml.jackson.databind.deser.impl.CreatorCandidate.Param;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.SpatialMath;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.graph.Network;
import repast.simphony.space.grid.Grid;

public class Node {

	// Repast variables
	@SuppressWarnings("unused")
	private ContinuousSpace<Object> space;
	private Context context;
	
	// Simulation Variables
	private String label;
	private int tick;
	private Network<Object> net;
	private double labelOffsetX;
	private double labelOffsetY;
	
	// Node Variables
	private int ID;	
	private int orderOfNode;
	private int numberOfBits;
	private FingerTable fingerTable;
	private Node predecessor;
	private int fingerToFix;
	
	private boolean REMOVED;
	private Parameters params;
	
	// DHT Variables
	private DHT<String> dht;
	private HashSet<String> values;
		
	/**
	 * Creation of a new Node
	 * @param numNode The numNode^th node
	 * @param ID Its ID in the ID space of Chord
	 * @param numberOfBits Number of bits generating the space
	 * @param space Repast variable containing all the object in the screen
	 * @param context Same as before
	 */
	@SuppressWarnings("unchecked")
	public Node(int numNode, int ID, int numberOfBits, ContinuousSpace<Object> space, Context<?> context, DHT<String> dht) {
		
		// Just copy the values
		this.ID = ID;
		this.space = space;
		this.context = context;
		this.orderOfNode = numNode;
		this.numberOfBits = numberOfBits;
		this.label = String.valueOf(ID);
		this.REMOVED = false;
		this.fingerToFix = RandomHelper.nextIntFromTo(0, numberOfBits - 1);
		this.params = RunEnvironment.getInstance().getParameters();
		this.dht = dht;
		this.values = new HashSet<String>();
		
		// Create a new FingerTable, initially all pointer are set to null
		this.fingerTable = new FingerTable(numberOfBits);
		
		// Get the network object (used for graphical purposes)
		this.net = (Network<Object>) context.getProjection("messages");
		
	}	

	/**
	 * Method that is executed at each clock tick, starting from 1
	 * It contains the call to stabilize.
	 * Randomly it exits from the system 
	 */
	@ScheduledMethod(start = 1, interval = 1)
	public void step() {
		
		// Clear label
		resetLabel();
		
		if(!REMOVED) {
			// Get tick count
			this.tick = (int) RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
			
			// Every n ticks run the stabilize method
			if(this.tick%5 == 0) {
				stabilize();
			}
			// Every n ticks run the stabilize method
			if(this.tick%2 == 0) {
				fixFinger();
			}
			
		}
		
	}
	
	/**
	 * The node exits the network and comunicates that to the neighbours
	 */
	public void leave() {
		
		System.out.println("Node " + this.ID + " left");
		
		// Remove myself from the neighbours
		this.getSuccessor().setPredecessor(predecessor);
		predecessor.setSuccessor(this.getSuccessor());
		
		this.REMOVED = true;
		context.remove(this);
		
	}
	
	/**
	 * Update a finger to be consistent with the local state of chord
	 * fixFinger is called periodically over the time on a different finger
	 * defined by the fingerToFx variable
	 */
	private void fixFinger() {
		int target = (this.ID + (int)Math.pow(2, fingerToFix)) % ((int)Math.pow(2, this.numberOfBits));
		fingerTable.setReference(fingerToFix, lookup(target, null));
		fingerToFix = (fingerToFix + 1) % numberOfBits;
	}
	
	/**
	 * This function identify the node which is responsible for that particular ID.
	 * This is a "recursive" function. It is called again on the target node.
	 * @param IDTarget ID to be looked up
	 * @return The node responsible for it
	 */
	public Node lookup(int IDTarget, int[] length) {
		
		int source = this.ID;
		if(IDTarget == source) {
			return this;
		}
		
		// For each finger
		for(int i = this.numberOfBits - 1; i >= 0; i--) {
			
			Node reference = fingerTable.getReference(i);	
						
			// If it is not set, skip
			if(!reference.isREMOVED()) {
						
				int attempt = reference.getID();	

				if(attempt != this.ID) {
					boolean hop = attempt < source;			
					
					// Consider the crossing between 2^n - 1 and ID 0
					boolean hopAndGreater = hop && IDTarget < source && IDTarget >= attempt;
					boolean notHopAndGreater = !hop && !(IDTarget > source && IDTarget < attempt);		
									
					if(hopAndGreater || notHopAndGreater) {
						if(length != null) {
							length[0]++;	
						}
						return fingerTable.getReference(i).lookup(IDTarget, length);
					}
				}
				
			} else {				
				// Update null finger with the greater finger
				if(i != this.numberOfBits - 1) {
					fingerTable.setReference(i, fingerTable.getReference(i+1));
				}
			}
			
		}

		return this.getSuccessor();
		
	}
	
	/**
	 * Try to update predecessor and successor of the node.
	 * Called periodically over time
	 */
	public void stabilize() {

		Node mySucc = this.getSuccessor();
		while(true) {
			if(mySucc.getPredecessor().getID() == this.ID) {
				this.setSuccessor(mySucc);
				break;
			} else {
				mySucc = mySucc.getPredecessor();
			}
		}
		
	}
	
	
	// ============================ fillFingerTable(...) ============================
	// Two overloaded methods, once used in the initialization of the simulation
	// And another one when a new node is generated
	
	/**
	 * This function will fill the fingerTable of the node
	 * @param allNodes At the beginning every nodes has the list of all the nodes in the system
	 */
	public void fillFingerTable(ArrayList<Node> allNodes) {
		
		System.out.println("======= Finger Table node: " + this.ID + " =======");
		
		// FOr each "finger"
		for(int i = 0; i <= this.numberOfBits - 1; i++) {
			
			int IDReached = (this.ID + (int)Math.pow(2, i))%((int)Math.pow(2, this.numberOfBits));
			System.out.print("    (" + this.ID + " + 2^" + i + ")%" + ((int)Math.pow(2, this.numberOfBits)) + " = " + IDReached + "\t-> ");

			// For each node, find the suitable finger
			Node fingerNode = allNodes.get(0);
			for(int j = 0; j < allNodes.size(); j++) {
				if(allNodes.get(j).getID() >= IDReached) {
					fingerNode = allNodes.get(j);
					break;
				}
			}
			
			System.out.println(fingerNode.getID());			
			fingerTable.setReference(i, fingerNode);
			
		}
		
	}

	/**
	 * This function tries to create the finger table when a new node join the network
	 * @param inNode Known node inside the system
	 */
	public void fillFingerTable(Node inNode) {
		
		System.out.println("New node " + this.ID + " joins");
		
		this.setSuccessor(inNode.lookup(this.ID, null));
		this.predecessor = getSuccessor().getPredecessor();
		// System.out.println(" --> 0 : " + getSuccessor().getID());
		
		// HOW FILL FINGER TABLE
		for(int i = 1; i < this.numberOfBits; i++) {
			
			Node target = inNode.lookup((int)((this.ID + Math.pow(2, i))%(Math.pow(2, this.numberOfBits))), null);			
			this.fingerTable.setReference(i, target);
			
			// System.out.println(" --> " + i + " : " + this.fingerTable.getReference(i).getID());
		}
		
		getSuccessor().setPredecessor(this);
		predecessor.setSuccessor(this);
		
	}	
	

	// ============================ Graphical Functions =============================

	/**
	 * Move the node into the circle in the position relative to its ID
	 * @param maxID used for computing the angle given the proportion with the angle and 360 degrees
	 */
	public void updatePosition(int maxID) {
		
		// Understand which is the bigger dimension
		// So as We can build a square based on the smallest one
		double width = space.getDimensions().getWidth();
		double height = space.getDimensions().getHeight();		
		double minimumSize = Math.min(width, height);
		
		// Move into the centre of the scene
		space.moveTo(this, width/2, height/2);
						
		double offsetAngleInRad = -((360*this.ID)/(double)maxID)*0.0174533;
		
		space.moveByVector(this, (minimumSize/2)*0.8, offsetAngleInRad + Math.PI/2, 0);	
		
		// update the position of the label
		double l  = 25;		
		double angle = (this.ID * Math.PI * 2)/maxID;
		double newAngle;
		if(angle <= (Math.PI/2.0)) {
			newAngle = (Math.PI/2.0) - angle;
		}
		else {
			newAngle = (5.0/2.0)*Math.PI - angle;
		}
		
		labelOffsetX = -(l * Math.cos(newAngle));
		labelOffsetY = l * Math.sin(newAngle);
		
	}
	
	

	// ================================== DHT Interface ==================================
	// ================================ Application Level ================================

	/**
	 * This function is called by the Controller, which wants this node to add a value into the DHT
	 * This is an instruction for the node
	 * @param str The string to be added
	 * @return true if everything's ok
	 */
	public boolean dhtAdd(String str) {
		return dht.add(str, this);
	}	

	/**
	 * This function is called by the Controller, which wants this node to remove a value from the DHT
	 * This is an instruction for the node
	 * @param str The string to be added
	 * @return true if item deleted
	 */
	public boolean dhtRemove(String str, boolean drawEdge) {
		return dht.removeEvent(str, this, drawEdge);
	}	

	/**
	 * Get whole itemset of the node
	 * This function is called by the Controller to manage the join/leave of nodes
	 * @return The whole itemset of the node
	 */
	public HashSet<String> dhtGet() {
		return this.values;
	}	

	/**
	 * Merge the DHT values from another node
	 * @param backup The values
	 */
	public void dhtMerge(HashSet<String> backup) {
		for(String s : backup) {
			this.values.add(s);
		}
	}	
	
	/**
	 * Check whether DHT contains the string
	 * @param str String to be checked
	 * @return If the string is contained in DHT
	 */
	public boolean dhtHas(String str) {
		return dht.has(str, this);
	}
	
	// ========================================= DHT Interface =========================================
	//          Note that the function above this line are called from the requester (Forward)
	//     Whereas the below ones are called from the DHT as a response to those requests (Backward)
	// =========================================== DHT Level ===========================================

	/**
	 * Store the given values in the local list of the node
	 * @param str The value to be stored
	 * @return If the value have been added
	 */
	public boolean store(String str) {
		this.label = this.label + " + [" + str + "]";
		return this.values.add(str);
	}

	/**
	 * Remove the given values in the local list of the node
	 * @param str The value to be removed
	 * @return If the value have been removed
	 */
	public boolean remove(String str) {
		return this.values.remove(str);
	}


	/**
	 * Check whether the given element is contained in the local list of thenode
	 * @param str The value to be checked
	 * @return If the value have been found
	 */
	public boolean has(String str) {
		return this.values.contains(str);
	}
	
	/**
	 * Called from GET by Controller
	 */
	public void toStringValues() {
		System.out.print("   > ");
		for(String s : this.values) {
			System.out.print(s + " ");
		}
		System.out.println();
	}
	
	/**
	 * Reset DHT
	 */
	public void dhtEmpty() {
		this.values.clear();
	}
	
	// ================================== GETTER ==================================
	
	public Node getSuccessor() {
		return this.fingerTable.getReference(0);
	}
	
	public String getLabel() {
		return this.label;
	}
	
	public int getID() {
		return ID;
	}	
	
	public Node getPredecessor() {
		return predecessor;
	}	
	
	public boolean isREMOVED() {
		return REMOVED;
	}

	public int getNumberOfBits() {
		return numberOfBits;
	}
	
	public int getMaxIdAvailable() {
		return ((int)(Math.pow(2, this.numberOfBits)));
	}
	
	public double getLabelOffsetX() {
		return labelOffsetX;
	}
	
	public double getLabelOffsetY() {
		return labelOffsetY;
	}

	// ================================== SETTER ==================================
	
	public void setPredecessor(Node predecessor) {
		this.predecessor = predecessor;
	}
	
	public void setSuccessor(Node successor) {
		this.fingerTable.setReference(0, successor);
	}
	
	public void resetLabel() {
		this.label = String.valueOf(this.ID) + " <";
		for(String s : this.values) {
			this.label = this.label + s + " ";
		}
		if(this.values.size() > 0) {
			this.label = this.label.substring(0, this.label.length() - 1);
		}
		this.label += ">";
	}
	
	// Simulation and data-collection function
	public int keysStored() {
		return this.values.size(); 
	}
	
}
