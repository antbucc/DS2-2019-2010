package chord;

import java.awt.Font;

import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import repast.simphony.visualizationOGL2D.StyleOGL2D;

/**
 * Style class of the agent Node
 */
@SuppressWarnings("rawtypes")
public class NodeStyle extends DefaultStyleOGL2D implements StyleOGL2D {
	
	@Override
	public Font getLabelFont(Object object) {
		return new Font("Calibri", Font.PLAIN, 16);
	}

	@Override
	public float getLabelXOffset(Object object) {
		if(object instanceof Node) {
			Node n = (Node) object;
			return( (float)n.getLabelOffsetX() );
		}
		return 0;
	}
	
	@Override
	public float getLabelYOffset(Object object) {
		if(object instanceof Node) {
			Node n = (Node) object;
			return( (float)n.getLabelOffsetY() - 8 );
		}
		return -8;
	}
	
	@Override
	public String getLabel(Object agent) {
		if (agent instanceof Node) {
			Node node = (Node) agent;
			return node.getLabel();
		}
		return super.getLabel(agent);
	}

}
