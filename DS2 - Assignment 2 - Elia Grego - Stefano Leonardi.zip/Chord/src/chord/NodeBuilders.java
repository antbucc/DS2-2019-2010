package chord;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.TreeSet;

import repast.simphony.context.Context;
import repast.simphony.context.space.continuous.ContinuousSpaceFactory;
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder;
import repast.simphony.context.space.graph.NetworkBuilder;
import repast.simphony.dataLoader.ContextBuilder;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.parameter.Parameters;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.RandomCartesianAdder;

public class NodeBuilders implements ContextBuilder<Object> {
	
	@Override
	public Context<Object> build(Context<Object> context) {	

		NetworkBuilder<Object> netBuilder = new NetworkBuilder<Object>("messages", context, true);
		netBuilder.buildNetwork();

		Parameters params = RunEnvironment.getInstance().getParameters();		
		context.setId("Chord");
		
		// Create the space
		// The references "space" is in the context.xml file
		ContinuousSpaceFactory spaceFactory = ContinuousSpaceFactoryFinder.createContinuousSpaceFactory(null);
		ContinuousSpace<Object> space = spaceFactory.createContinuousSpace("space", context, new RandomCartesianAdder<Object>(), new repast.simphony.space.continuous.WrapAroundBorders(), 50, 50);

		Random random = new Random();

		int numberOfBits = params.getInteger("m");
		numberOfBits = Math.max(numberOfBits, 2);
		numberOfBits = Math.min(numberOfBits, 20);
		int maxIDAvailable = (int)Math.pow(2, numberOfBits);
		
		int numberOfNodes = params.getInteger("startNumNodes");
		numberOfNodes = Math.max(numberOfNodes, 2);
		numberOfNodes = Math.min(numberOfNodes, maxIDAvailable);
		ArrayList<Node> nodes = new ArrayList<Node>();

		DHT<String> dht = new DHT<String>(space, context, maxIDAvailable);	
		
		// Get numberOfNodes DIFFERENT and ordered identifiers
		TreeSet<Integer> identifiers = new TreeSet<Integer>();
		while(identifiers.size() != numberOfNodes) {
			identifiers.add(random.nextInt(maxIDAvailable));
		}
		
		// The variable nodeNumber is used for specific simulation tests
		// For example we can select easily the third node in the netwrok
		// While it is hard to select the node which has identifier XX
		int nodeNumber = 0;
		for (int id : identifiers) {	
			// Create the node and add it to the context
			Node n = new Node(nodeNumber, id, numberOfBits, space, context, dht);
			nodes.add(n);
			context.add(n);
			// Update its position into the circle accordingly to its ID
			n.updatePosition(maxIDAvailable);
			nodeNumber++;
		}
		
		// Once nodes are created, we update their finger tables
		// And we set also the predecessor (used for the stabilize)
		Node nodePrec = nodes.get(nodes.size()-1);
		for(Node node : nodes) {
			node.fillFingerTable(nodes);
			node.setPredecessor(nodePrec);
			nodePrec = node;
		}
				
		// Used for generating new node into the system
		Controller controller = new Controller(space, context, maxIDAvailable, numberOfBits, dht);
		context.add(controller);
		
		// Set the controller in the center of the screen
		double width = space.getDimensions().getWidth();
		double height = space.getDimensions().getHeight();		
		space.moveTo(controller, width/2.0, height/2.0);
		
		return context;
		
	}	

}
