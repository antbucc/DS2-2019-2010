package chord;

import java.awt.Color;

import repast.simphony.space.graph.RepastEdge;
import repast.simphony.visualizationOGL2D.EdgeStyleOGL2D;

public class ArcStyle implements EdgeStyleOGL2D {
	
	@Override
	public int getLineWidth(RepastEdge<?> edge) {
		MyEdge myedge = (MyEdge)edge;
		int type = myedge.getEventType();
		if(type == 4) {
			return 2;
		}
		else {
			return 1;
		}
	}

	@Override
	public Color getColor(RepastEdge<?> edge) {
		MyEdge myedge = (MyEdge)edge;
		int type = myedge.getEventType();
		switch (type) {
			case 0:	return Color.GREEN;
			case 1:	return Color.RED;
			case 2:	return Color.YELLOW;
			case 4:	return Color.BLUE;
			default: return Color.CYAN;
		}
	}

}
