package chord;

import repast.simphony.space.graph.RepastEdge;

public class MyEdge extends RepastEdge<Object> {
	
	private int eventType;
	
	public MyEdge(Object source, Object target, int eventType) {
		super(source, target, true);
		this.eventType = eventType;
	}
	
	public int getEventType() {
		return eventType;
	}

}
