package chord;

import java.util.ArrayList;

/**
 * This class defines a FingerTable, each finger correspond to a Finger class
 *
 */
public class FingerTable {

	ArrayList<Finger> table;
	
	/**
	 * Constructor.
	 * It instanciate all the reference fingers to null
	 * @param numberOfBits
	 */
	public FingerTable(int numberOfBits) {
		this.table = new ArrayList<Finger>();
		for(int i = 0; i <= numberOfBits - 1; i++) {
			this.table.add(new Finger((int)Math.pow(2, i)));
		}
	}
	
	// ================== Get and set ==================

	/**
	 * Set the reference to the selected finger
	 * @param exp The ith finger
	 * @param node The node reference
	 */
	public void setReference(int exp, Node node) {
		table.get(exp).setReference(node);
	}
	
	/**
	 * Get the node placed in the relative finger
	 * @param exp The ith finger
	 * @return The reference node
	 */
	public Node getReference(int exp) {
		return table.get(exp).getReference();
	}
	
}
