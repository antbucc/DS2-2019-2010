package chord;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.graph.Network;

/**
 * This class is used for the creation of new nodes during the simulation
 */
public class Controller {

	// Repast variables
	@SuppressWarnings("unused")
	private ContinuousSpace<Object> space;
	private Context context;
	
	private int tick;
	private int maxIDAvailable;
	private int numOfBits;	
	
	// DHT Variables
	private DHT<String> dht;
	private Node target;
	private HashSet<String> generatedValues;
	
	// Repast
	private Network<Object> net;		
	private Parameters params;
	
	// Simulation
	private int valuesMoved;
	
	/**
	 * Constructor
	 * @param space Repast Variable
	 * @param context Repast Variable
	 * @param nodes All the nodes in the network
	 * @param maxIDAvailable Last ID available (2^m - 1)
	 * @param numOfBits In the ID space (m)
	 */
	@SuppressWarnings("unchecked")
	public Controller(ContinuousSpace<Object> space, Context context, int maxIDAvailable, int numOfBits, DHT<String> dht) {
		
		this.space = space;
		this.context = context;
		this.maxIDAvailable = maxIDAvailable;
		this.numOfBits = numOfBits;
		this.params = RunEnvironment.getInstance().getParameters();
		this.dht = dht;
		this.generatedValues = new HashSet<String>();
		this.net = (Network<Object>) context.getProjection("messages");
		
		this.valuesMoved = 0;
		
	}
	
	public boolean randProb1_1000(String what) {
		int rand = RandomHelper.nextIntFromTo(1, 1000);
		int prob = this.params.getInteger(what);
		
		// Bound 0 - 1000
		prob = Math.min(1000, prob);
		prob = Math.max(0, prob);
		
		// If lucky
		return(rand <= prob);
	}
	
	/**
	 * Controller process
	 * It will generate nodes randomly
	 */
	@ScheduledMethod(start = 1, interval = 1)
	public void step() {
		
		// Get tick count
		this.tick = (int) RunEnvironment.getInstance().getCurrentSchedule().getTickCount();	
		net.removeEdges();
		
		// ==================== MEMBERSHIP ======================		
		// ======================= Join =========================	

		// Get simulation parameters
		// Parameters params = RunEnvironment.getInstance().getParameters();

		ArrayList<Node> existingNodes = getNodes(true);
		
		// Handle probability of unsubscription
		if (randProb1_1000("probOfNodeGeneration")) {
			addNewNode(existingNodes);					
		}
		
		// ==================== Leave ========================
		if (randProb1_1000("probOfLeaving")) {			
			removeNode(existingNodes);			
		}		
		

		// ==================== EVENTS MANAGEMENT ======================
		
		// It's time to clean the DHT
		int resetCount = this.params.getInteger("resetCount");		
		if(tick%resetCount == 0) {
			dht.reset();
		}

		int howManyEvents = this.params.getInteger("howManyEvents");
		for(int eventNumber = 0; eventNumber < howManyEvents; eventNumber++) {	

			existingNodes = getNodes(false);
			if(existingNodes.size() > 0) {	
					
				// Select the target
				int targetId = RandomHelper.nextIntFromTo(0, existingNodes.size() - 1);
				target = existingNodes.get(targetId);
				net.addEdge(new MyEdge(this, target, 4));
				
				//System.out.println("\nSource " + target.getID() + ": ");
	
				contains();
				remove();
				add();	
				get();
				
			}		
			
		}
		
	}
	
	/**
	 * Function that chose one node inside the network and creates a brand new one.
	 */
	@SuppressWarnings("unchecked")
	public void addNewNode(ArrayList<Node> existingNodes) {

		// Pick one random existing node				
		if(existingNodes.size() > 0 && existingNodes.size() < maxIDAvailable) {
			
			int inNodeId = RandomHelper.nextIntFromTo(0, existingNodes.size() - 1);
			Node inNode = existingNodes.get(inNodeId);			
			boolean found = false;
			int newId = 0;
			
			// Find a new ID
			while(!found) {			
				found = true;			
				newId = RandomHelper.nextIntFromTo(0, this.maxIDAvailable - 1);
				for(Node node : existingNodes) {
					if(node.getID() == newId) {
						found = false;
						break;
					}
				}			
			}
			
			// Create the node
			Node newNode = new Node(existingNodes.size(), newId, numOfBits, space, context, dht);
			this.context.add(newNode);
			
			newNode.updatePosition(maxIDAvailable);		
			newNode.fillFingerTable(inNode);
			
			// Update DHT
			HashSet<String> valuesHoldBySuccessor = newNode.getSuccessor().dhtGet();
			HashSet<String> toRemoveFromSucc = new HashSet<String>();
			
			for(String item : valuesHoldBySuccessor) {
				int hash = item.hashCode() % this.maxIDAvailable;
				int succId = newNode.getSuccessor().getID();
				if(succId > newId) {    // normal scenario, the successor is greater
					if(hash <= newId || hash > succId) { // the id need to be moved
						toRemoveFromSucc.add(item);
					}
				} else { // the successor is lower
					if(hash <= newId && hash > succId) {
						toRemoveFromSucc.add(item);
					}
				}
			}
			
			// Simulation analysis
			valuesMoved += toRemoveFromSucc.size();
			
			newNode.dhtMerge(toRemoveFromSucc);
			for(String str : toRemoveFromSucc) {
				newNode.getSuccessor().dhtRemove(str, false);
			}
			newNode.resetLabel();
			
		}
	}
	
	public void removeNode(ArrayList<Node> existingNodes) {
		
		if(existingNodes.size() > 0) {	
			
			int outNodeId = RandomHelper.nextIntFromTo(0, existingNodes.size() - 1);
			Node outNode = existingNodes.get(outNodeId);		

			// Update DHT
			HashSet<String> backup = outNode.dhtGet();
			outNode.getSuccessor().dhtMerge(backup);
			
			// Physical remove
			outNode.leave();
			
		}		
		
	}

	// ================================== DHT Functions ==================================
	
	public void add() {
		if (randProb1_1000("probOfEventAdd")) {				
			// Generate a random string as an EVENT
			int leftLimit = 97; // letter 'a'
			int rightLimit = 122; // letter 'z'
			int targetStringLength = 2;
			Random random = new Random();
			StringBuilder buffer = new StringBuilder(targetStringLength);
			for (int i = 0; i < targetStringLength; i++) {
				int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
				buffer.append((char) randomLimitedInt);
			}
			String str = buffer.toString().toUpperCase();				
			if(!target.dhtAdd(str)) {
				//System.out.println("   > Item " + str + " NOT added to the DHT");
			}
			else {
				//System.out.println("   > Item " + str + " added to the DHT");
				generatedValues.add(str);
			}			
		}			
	}
	
	public void get() {
		if (randProb1_1000("probOfEventGet")) {		
			System.out.print("[GET] values: ");
			if(target.dhtGet().size() > 0) {
				System.out.println();
				target.toStringValues();
			}
			else {
				System.out.println("EMPTYSET");
			}
		}	
	}
	
	public void remove() {
		if (randProb1_1000("probOfEventRemove")){			
			if(generatedValues.size() > 0) {
				int indexToRemove = RandomHelper.nextIntFromTo(0, generatedValues.size() - 1);
				Iterator<String> iter = generatedValues.iterator();
				for (int i = 0; i < indexToRemove; i++) {
				    iter.next();
				}
				String toRemove = iter.next();
				if(!target.dhtRemove(toRemove, true)) {
					System.out.println("   > Item " + toRemove + " NOT removed from the DHT");
				}
				else {
					System.out.println("   > Item " + toRemove + " removed from the DHT");						
				}
			}	
		}	
	}
	
	public void contains() {
		if (randProb1_1000("probOfEventContains")) {
			if(generatedValues.size() > 0) {
				int indexToRemove = RandomHelper.nextIntFromTo(0, generatedValues.size() - 1);
				Iterator<String> iter = generatedValues.iterator();
				for (int i = 0; i < indexToRemove; i++) {
				    iter.next();
				}
				String toSearch = iter.next();
				if(!target.dhtHas(toSearch)) {
					System.out.println("   > Item " + toSearch + " NOT found on the DHT!");
				}
				else {
					System.out.println("   > Item " + toSearch + " found on the DHT!");						
				}
			}
		}	
	}
	

	// ================================== GETTER ==================================
	
	public Context getContext() {
		return context;
	}
	
	public int getTick() {
		return tick;
	}
	
	public ContinuousSpace<Object> getSpace() {
		return space;
	}
	
	public ArrayList<Node> getNodes(boolean reset){
		ArrayList<Node> existingNodes = new ArrayList<Node>();
		for(Object obj : space.getObjects()) {
			if(obj instanceof Node) {
				Node node = (Node) obj;
				if(reset) { node.resetLabel(); }
				existingNodes.add(node);
			}
		}
		return existingNodes;
	}

	// ================================== Simulation ==================================
	public int getValuesMoved() {
		return valuesMoved;
	}
	
}
