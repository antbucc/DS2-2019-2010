package chord;

import java.util.ArrayList;

import org.apache.tools.ant.taskdefs.Tar;

import repast.simphony.context.Context;
import repast.simphony.context.space.graph.NetworkBuilder;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.graph.Network;

/**
 * Class simulating a Distributed Hash Table
 * Each node is responsible for a set of keys, and it holds every items hashing to these keys
 * Furthermore, nodes randomly generate values to be saved on the system 
 * 
 * T is the object type
 * 
 */
public class DHT<T> {
	
	private ContinuousSpace<Object> space;
	private Network<Object> net;
	private int maxValue;
	
	public DHT(ContinuousSpace<Object> space, Context<?> context, int maxValue) {
		this.space = space;
		this.maxValue = maxValue;
		this.net = (Network<Object>) context.getProjection("messages");
	}
	
	private ArrayList<Node> getNodes(){
		ArrayList<Node> nodes = new ArrayList<Node>();
		for(Object obj : space.getObjects()) {
			if(obj instanceof Node) {
				nodes.add((Node) obj);
			}
		}
		return nodes;
	}

	public boolean add(String str, Node source) {
		int hashed = str.hashCode() % this.maxValue;
		
		//SIMULATION
		hashed = RandomHelper.nextIntFromTo(0, maxValue - 1);
		int[] length = new int[1];
		length[0] = 0;
		Node target = source.lookup(hashed, length);
		System.out.println("Path length: " + length[0]);

		//System.out.println("[ADD] h(\"" + str + "\") = " + hashed + ". In " + target.getID());
		net.addEdge(new MyEdge(source, target, 0));
		return target.store(str);
	}
	
	public boolean removeEvent(String str, Node source, boolean drawEdge) {
		Node target = source;
		if(drawEdge) {
			int hashed = str.hashCode() % this.maxValue;
			target = source.lookup(hashed, null);
			System.out.println("[REMOVE] h(\"" + str + "\") = " + hashed + ". In " + target.getID());
			net.addEdge(new MyEdge(source, target, 1));
		}
		return target.remove(str);
	}
	
	public boolean has(String str, Node source) {
		int hashed = str.hashCode() % this.maxValue;
		Node target = source.lookup(hashed, null);
		System.out.println("[CONTAINS] h(\"" + str + "\") = " + hashed + ". In " + target.getID());
		net.addEdge(new MyEdge(source, target, 2));
		return target.has(str);
	}
	
	/**
	 * Remove all the items from the DHT
	 */
	public void reset() {
		ArrayList<Node> nodes = getNodes();
		for(Node n : nodes) {
			n.dhtEmpty();
		}
	}

}
