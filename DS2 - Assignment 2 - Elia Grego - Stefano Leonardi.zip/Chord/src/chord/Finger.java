package chord;

public class Finger implements Comparable<Finger> {

	private int key;
	private Node reference;

	public Finger(int key) {
		this.key = key;
		this.reference = null;
	}
	
	public Finger(int key, Node reference) {
		this.key = key;
		this.reference = reference;
	}
	
	public int getKey() {
		return key;
	}
	
	public Node getReference() {
		return reference;
	}
	
	public void setReference(Node reference) {
		this.reference = reference;
	}

	@Override
	public int compareTo(Finger o) {
		return o.getKey() - this.key;
	}
	
}
