# set the environment
setwd("~/Documents/Universita/Corsi/5Anno/DS2/lab/2019/Progetto1/")

library(dplyr)
library(ggplot2)
library(Hmisc)

folder_n_experiments1 <- "dif_f/neigh_3"
folder_n_experiments2 <- "dif_f/neigh_4"
folder_n_experiments3 <- "dif_f/neigh_5"
folder_n_experiments4 <- "dif_f/neigh_6"

files_n_experiment1 <- list.files(folder_n_experiments1,full.names = TRUE)
files_n_experiment2 <- list.files(folder_n_experiments2,full.names = TRUE)
files_n_experiment3 <- list.files(folder_n_experiments3,full.names = TRUE)
files_n_experiment4 <- list.files(folder_n_experiments4,full.names = TRUE)

csv1 = read.csv(files_n_experiment1[9])
csv2 = read.csv(files_n_experiment2[9])
csv3 = read.csv(files_n_experiment3[9])
csv4 = read.csv(files_n_experiment4[9])

pdf("fixed_view_variable_f.pdf", width = 11.69, height = 8.27)
plot(csv1$tick, csv1$Infected,type="l", col="black", 
     main="Variable F, number of infected nodes",
     xlab="Rounds [infection starts at round 10]",
     ylab="# infected nodes",
        xlim = c(0,20),
     cex.lab = 1.5, cex.axis = 1.7, cex.main = 2)
lines(csv2$tick, csv2$Infected, type="l",col="blue" )
lines(csv3$tick, csv3$Infected, type="l",col="green" )
lines(csv4$tick, csv4$Infected, type="l",col="red" )
legend("topleft", legend=c("F = 3", "F = 4", "F = 5", "F = 6"),
       col=c("black", "blue", "green", "red"),lty=1:1, cex=1.8,)
dev.off()


folder_v_experiments1 <- "dif_v/l_10"
folder_v_experiments2 <- "dif_v/l_15"
folder_v_experiments3 <- "dif_v/l_20"

files_v_experiment1 <- list.files(folder_v_experiments1,full.names = TRUE)
files_v_experiment2 <- list.files(folder_v_experiments2,full.names = TRUE)
files_v_experiment3 <- list.files(folder_v_experiments3,full.names = TRUE)

csv1 = read.csv(files_v_experiment1[9])
csv2 = read.csv(files_v_experiment2[9])
csv3 = read.csv(files_v_experiment3[9])

pdf("fixed_f_variable_view.pdf", width = 11.69, height = 8.27)
plot(csv1$tick, csv1$Infected,type="l", col="black", 
     main="Variable view, number of infected nodes",
     xlab="Rounds [infection starts at round 10]",
     ylab="# infected nodes",
     xlim = c(0,20),
     cex.lab = 1.5, cex.axis = 1.7, cex.main = 2)
lines(csv2$tick, csv2$Infected, type="l",col="blue" )
lines(csv3$tick, csv3$Infected, type="l",col="green" )
legend("topleft", legend=c("View = 10", "View = 15", "View = 20"),
       col=c("black", "blue", "green"),lty=1:1, cex=1.8,)
dev.off()


folder_fixed_experiment <- "fixed_v_and_f"
files_fixed <- list.files(folder_fixed_experiment,full.names = TRUE)


csv1 <- read.csv(files_fixed[2])
csv2 <- read.csv(files_fixed[4])
csv3 <- read.csv(files_fixed[10])

pdf("fixed_f_fixed_view_different_ns.pdf", width = 11.69, height = 8.27)
plot(csv1$tick, csv1$Infected, type="l", col="black",
     main="Variable view, number of infected nodes",
     xlab="Rounds [infection starts at round 10]",
     ylab="# infected nodes",
     xlim = c(7,15),
     ylim = c(0, 1200),
     cex.lab = 1.5, cex.axis = 1.7, cex.main = 2)
lines(csv2$tick, csv2$Infected, type="l",col="blue" )
lines(csv3$tick, csv3$Infected, type="l",col="green" )
legend("topleft", legend=c("N = 200", "N = 400", "N = 1000"),
        col=c("black", "blue", "green"),lty=1:1, cex=1.8,)
dev.off()

n_nodes <- c()
conv_round <- c()
for (file in files_fixed) {
        csv_obj <- read.csv(file)
        csv_obj_first <- csv_obj[match(unique(csv_obj$Infected), csv_obj$Infected),]
        csv_n_nodes <- max(csv_obj_first$Infected)
        n_nodes <- c(n_nodes, csv_n_nodes)
        n_round <- max(csv_obj_first$tick)
        conv_round <- c(conv_round, n_round)
}

data <- data.frame(n_nodes, conv_round)
print(data)

pdf("fixed_view_fixed_f.pdf", width = 11.69, height = 8.27)
plot(data$n_nodes, data$conv_round,type="l", col="black", 
     main="Fixed F, Fixed view, number of infected nodes",
     xlab="Number of nodes in the network",
     ylab="# round to infect all nodes",
     xlim = c(100,1000),
     ylim = c(10, 16),
     cex.lab = 1.5, cex.axis = 1.7, cex.main = 2)
dev.off()
