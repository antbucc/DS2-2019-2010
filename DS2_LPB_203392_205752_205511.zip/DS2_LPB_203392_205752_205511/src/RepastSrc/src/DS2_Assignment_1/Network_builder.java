package DS2_Assignment_1;

import java.util.ArrayList;

import DS2_Assignment_1.StdRandom;

import DS2_Assignment_1.Node;
import repast.simphony.context.Context;
import repast.simphony.context.space.continuous.ContinuousSpaceFactory;
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder;
import repast.simphony.context.space.graph.NetworkBuilder;
import repast.simphony.context.space.grid.GridFactory;
import repast.simphony.context.space.grid.GridFactoryFinder;
import repast.simphony.dataLoader.ContextBuilder;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduleParameters;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.continuous.RandomCartesianAdder;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridBuilderParameters;
import repast.simphony.space.grid.SimpleGridAdder;
import repast.simphony.space.grid.WrapAroundBorders;
import repast.simphony.util.ContextUtils;
import repast.simphony.util.collections.IndexedIterable;


public class Network_builder implements ContextBuilder<Object> {
	/*
	 * Given a graph and a Node 'Source' returns the set of reachable neighbors strarting from 'source' node. 
	 * */
	private void DFS(ArrayList<ArrayList<Integer>> graph, int currentNode, ArrayList<Boolean> visited) {
		visited.set(currentNode, true);
		
		for (int elem : graph.get(currentNode)) {
			if(!visited.get(elem))
				DFS(graph, elem, visited);
		}
	}
	
	/*
	 * Check if the graph passed as parameter is strongly connected.
	 * */
	private boolean connected(ArrayList<ArrayList<Integer>> graph, int N) {
		for(int i = 0; i < N; i++) {
			ArrayList<Boolean> visited = new ArrayList<Boolean>(N);
			for(int j = 0; j < N; j++) {
				visited.add(false);
			}
			
			DFS(graph, i, visited);
			
			for(Boolean b : visited) {
				if(!b) {
					System.out.println("ERROR GRAPH NOT STRONGLY CONNECTED");
					return false;
				}
			}
		}
		return true;
	}
	
	@Override
	public Context build(Context<Object> context) {
		context.setId("DS2_Assignment_1");
		
		//network for messages 
		NetworkBuilder<Object> netBuilder_messages = new NetworkBuilder<Object>(
				"network_messages", context, true);
		netBuilder_messages.buildNetwork();
		
		//network for the retrieve messages 
		NetworkBuilder<Object> netBuilder_retrive = new NetworkBuilder<Object>(
				"network_retrive", context, true);
		netBuilder_retrive.buildNetwork();
		
		//network for the sub messages 
		NetworkBuilder<Object> netBuilder_sub= new NetworkBuilder<Object>(
				"network_sub", context, true);
		netBuilder_sub.buildNetwork();
		
		//network for view
		NetworkBuilder<Object> netBuilder_view= new NetworkBuilder<Object>(
				"network_view", context, true);
		netBuilder_view.buildNetwork();

		ContinuousSpaceFactory spaceFactory = ContinuousSpaceFactoryFinder
				.createContinuousSpaceFactory(null);
		ContinuousSpace<Object> space = spaceFactory.createContinuousSpace(
				"space", context, new RandomCartesianAdder<Object>(),
				new repast.simphony.space.continuous.WrapAroundBorders(), 50,
				50);

		GridFactory gridFactory = GridFactoryFinder.createGridFactory(null);
		Grid<Object> grid = gridFactory.createGrid("grid", context,
				new GridBuilderParameters<Object>(new WrapAroundBorders(),
						new SimpleGridAdder<Object>(), true, 50, 50));

		Parameters params = RunEnvironment.getInstance().getParameters();
		
		int nodes = (Integer) params.getValue("nodes");									//Number of nodes in the scenario
		int sub_length = (Integer) params.getValue("sub_length");						//Max length of subs set 
		int view_length = (Integer) params.getValue("view_length");						//Max length of the view
		int retrieve_source = (Integer) params.getValue("retrieve_source");				//number of rounds to wait before ask to random node or to the source
		int retrieve_rounds = (Integer) params.getValue("retrieve_rounds");				//number of round to wait before retrieve.
		int gossip_neigh = (Integer) params.getValue("gossip_neigh");					//number of random Nodes selected to receive a gossip message
		float sub_prob = (Float) params.getValue("sub_probability");					//Probability to join the set when a node is outside the set
		float association_prob = (Float) params.getValue("association_probability");	//Probability to have a neighbor
		float lose_msg_prob = (Float) params.getValue("lose_msg_prob");					//Probability of a message to be lost
		float failing_prob = (Float) params.getValue("failing_prob");					//Probability that the node crash.
		float unsub_prob = (Float) params.getValue("unsub_prob");						//Probability to unsub the set while a node is part of the set
		float gen_probability = (Float) params.getValue("gen_message");					//probability of generate new message
		int max_messagges = (Integer) params.getValue("max_messagges");	                //number of the total messages in the network
		
        ArrayList<ArrayList<Integer>> nodeViews;
		do {
			nodeViews = new ArrayList<ArrayList<Integer>>(nodes);
			for(int i = 0; i < nodes; i++) {
				nodeViews.add(new ArrayList<Integer>(nodes));
			}
			for (int i = 0; i < nodes; i++) {
	            for (int j = 0; j < nodes; j++) {
	            	//with a given probability add j to the view of i.
	            	if(StdRandom.bernoulli(association_prob)) {
	            		nodeViews.get(i).add(j);
	            	}
	            }
			}
		} while(!connected(nodeViews, nodes));
		
		Node.network_messagges = 0;
		for (int i = 0; i < nodes; i++) {
			//adding the nodes in the context
			context.add(new Node(i, nodeViews.get(i), view_length, sub_length, 
					gossip_neigh, retrieve_rounds, retrieve_source,
					sub_prob, unsub_prob, lose_msg_prob, failing_prob, gen_probability));
		}
		

		//set the maximum number of generated messages as a static variable 
		Node.total_messagges = max_messagges;
		
		ScheduleParameters param = ScheduleParameters.createOneTime(10);	//the tick at which schedule the event
		Node t = (Node) context.getRandomObject();							//target node chose at random
		
		
		//schedule the send of a tracked message
		RunEnvironment.getInstance().getCurrentSchedule().schedule(
				param,
				t,
				"generate_message_to_be_tracked");

		for (Object obj : context) {
			NdPoint pt = space.getLocation(obj);
			grid.moveTo(obj, (int) pt.getX(), (int) pt.getY());
		}
		
		//this is only for batch run
		if (RunEnvironment.getInstance().isBatch()) {
			RunEnvironment.getInstance().endAt(40);
		}

		return context;
	}

}
