package DS2_Assignment_1;

import java.util.ArrayList;

public class Gossip_message {
	
	ArrayList<String> events;		//list of events of the sender node
	ArrayList<String> eventids;		//list of events delivered by the sender node
	ArrayList<Integer> un_subs;		//list of unsubscription received by the sender node
	ArrayList<Integer> subs;		//list of subscription received by the sender node
	int sender;						//the id of the sender node
	int receiver;					//the id of the receiver
	boolean to_be_track;			//a boolean indicate if the message has to be track
	String event_to_trak;			//the event that has to be track 
	
	
	public Gossip_message(ArrayList<String> events, ArrayList<String> eventids, ArrayList<Integer> un_subs, ArrayList<Integer> subs, int sender, boolean to_be_trak, String event_to_trak) {
		this.events = events;
		this.eventids = eventids;
		this.un_subs = un_subs;
		this.subs = subs;
		this.sender = sender;
		this.to_be_track = to_be_trak;
		this.event_to_trak = event_to_trak;
	}
}
