package DS2_Assignment_1;
import java.awt.Color;

import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import DS2_Assignment_1.Node;
import java.awt.color.*;
public class NodeStyle extends DefaultStyleOGL2D {

	@Override
	public Color getColor(Object agent) {
		Node ag = (Node) agent;
		if(ag.getFailed_b()) {
			return Color.black;
		}
		if(!ag.getState()) {
			return Color.gray;
		}
		if(ag.getInfected_b()) {
			return Color.red;
		}
		return Color.blue;
		
	}

	@Override
	public float getScale(Object object) {
		// TODO Auto-generated method stub
		return 5;
	}

	
	
}
