package DS2_Assignment_1;

import DS2_Assignment_1.Gossip_message;
import DS2_Assignment_1.Element;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ISchedule;
import repast.simphony.engine.schedule.Schedule;
import repast.simphony.engine.schedule.ScheduleParameters;

import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.graph.Network;
import repast.simphony.space.graph.RepastEdge;
import repast.simphony.space.grid.Grid;
import repast.simphony.util.ContextUtils;
import repast.simphony.util.collections.IndexedIterable;
import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import repast.simphony.context.Context;

/**
 * A Node in the network that could send and receive message
 * from others nodes.
 * */
public class Node{
	
	private int id;								//unique id of the node
	private ArrayList<String> events;			//list of event ids that are not yet delivered to application
	private ArrayList<String> eventids;			//list of event ids that are already delivered
	private ArrayList<Integer> un_subs;			//list of Nodes that have unsubscribed to the topic
	private ArrayList<Integer> subs;			//list of Nodes that have subscribe to the topic
	private ArrayList<Integer> view;			//the current view of the Node (neighbors)
	private ArrayList<Element> retrive_buffer;	//the buffer containing all the retrieve requests 
	private int max_length_of_view;				//the max number of neighbors and max eventids
	private int max_length_of_sub;				//max number of subscription and unsubscription
	private int F;								//number of neighbors to gossip to
	private int K;								//number of rounds to wait before retrieve
	private int R;                          	//number of rounds to wait before ask to random node or to the source 
	private int current_round = 0;				//the internal time of the node increment it on each action 
	
	private int messageGenerated =0;        	//counter used to generate unique event ids
	private ArrayList<String> generatedEvent;	//the array of all the generated events by this node.
	private ArrayList<String> deliveredEvents;	//contains all events already delivered to app level 
	
	
	private boolean state = true;				//a variable that indicates the state of the node: true = sub, false = unsub from the topic
	private boolean failed = false;				//variable used to tell if the node is failed
	private boolean infected = false;			//variable to track the spreading of a message
	private String event_to_track = "";			//contain the id of the message to be tracked
	
	//probability of the node
	private float sub_prob;						//Probability to join the set when a node is outside the set
	private float unsub_prob;					//Probability to unsub the set while a node is part of the set
	private float lose_msg_prob; 				//Probability of a message to be lost
    private float failing_prob;					//probability of failure of the node
	private float gen_probability;				//probability of generate a new message
    
	//static variables
	public static int network_messagges;	
	public static int total_messagges;      	//static variable valid for each node to bound the number of messages generated in the network 
	public static int retrive_count = 0;		//static variable to count the number of retrieving messages
    			
	
	/**
	 * Constructor of the Node class
	 * @param id is the id of the node (unique)
	 * @param events buffer contain the events not yet delivered
	 * @param eventids buffer contain the event already delivered
	 * @param un_subs buffer containing the UNsubscription to be gossiped
	 * @param subs buffer containing the subscriprion to be gossiped
	 * @param view the current view of this process (neighbours)
	 * @param max_length_of_view is the max length of the buffer containing the node ids
	 * @param max_length_of_sub is the max length of the buffer containing subs and unsubs
	 * @param T time in milliseconds between a gossip and the next one
	 * @param F number of random Nodes selected to receive a gossip message
	 * @param K number of round to wait before retrieve.
	 * @param R number of rounds to wait before ask to random node or to the source 
	 * @param sub_prob Probability to join the set when a node is outside the set
	 * @param unsub_prob Probability to unsub the set while a node is part of the set
	 * @param lose_msg_prob Probability of a message to be lost
	 * @param failing_prob the probability that this node has to fail each round
	 * */
	public Node(int id,
			ArrayList<Integer> view,
			int max_length_of_view,
			int max_length_of_sub,
			int F,
			int K,
			int R,
			float sub_prob, 
			float unsub_prob, 
			float lose_msg_prob, 
			float failing_prob, 
			float gen_probability) {
		
		
		this.id = id;
		this.events = new ArrayList<String>();
		this.eventids = new ArrayList<String>();
		this.un_subs = new ArrayList<Integer>();
		this.subs = new ArrayList<Integer>();
		this.view = view; 			//pass the view form netbuilder but truncate if overflow the max size
		this.retrive_buffer = new ArrayList<Element>();
		this.max_length_of_view = max_length_of_view;
		this.max_length_of_sub = max_length_of_sub;
		this.F = F;
		this.K = K;
		this.R = R;
		this.sub_prob = sub_prob;
		this.unsub_prob = unsub_prob;
		this.lose_msg_prob = lose_msg_prob;
		this.generatedEvent = new ArrayList<String>();
		this.failing_prob = failing_prob;
		this.gen_probability = gen_probability;
		this.deliveredEvents = new ArrayList<String>();
	}
	
	
	/*
	 * Method used to handle a gossip message receive, is divided in three phases
	 * */
	public void on_gossip_receive(Gossip_message msg) {
		
		//only respond if i'm sub.
		if(this.state && !this.failed) {
			//check if is a message to be tracked.
			if(msg.to_be_track) {
				this.infected = true;
				this.event_to_track = msg.event_to_trak;
			}
			
			//System.out.println("Node: " + this.id + " Received a message from: " + msg.sender);
			//System.out.println("events: " + msg.events.toString());
			//System.out.println("eventids: " + msg.eventids.toString());
			//System.out.println("sub: " + msg.subs.toString());
			//System.out.println("un_sub: " + msg.un_subs.toString());
			
			//Phase I
			/*
			 * handling un_sunbs
			 * */
			//clean old subs from the message
			msg.subs.removeAll(msg.un_subs);
			this.view.removeAll(msg.un_subs);		//remove all un_sub from my view
			this.subs.removeAll(msg.un_subs);		//remove all un_sub from my subs
			msg.un_subs.removeAll(this.un_subs);	//keep only the un_subs that aren't in my un_subs
			this.un_subs.addAll(msg.un_subs);		//add un_subs that are not already in my un_subs
			
			removeRandomElements(this.un_subs, this.max_length_of_sub);	//truncate to max length
			
			//Phase II
			/*
			 * update the view
			 * */
			ArrayList<Integer> me = new ArrayList<Integer>();
			me.add(this.id);
			//this remove all the occurrences of me in msg.subs
			msg.subs.removeAll(me);
			
			for(int sub : msg.subs) {
				if(!this.view.contains(sub)) {
					this.view.add(sub);
					if(!this.subs.contains(sub)) {
						this.subs.add(sub);
					}
				}
			}
			
			ArrayList<Integer> truncated_from_view = new ArrayList<Integer>();
			truncated_from_view = removeRandomElements(this.view, this.max_length_of_view);
			truncated_from_view.removeAll(this.subs);
			this.subs.addAll(truncated_from_view);
			
			removeRandomElements(this.subs, this.max_length_of_sub);
			
			
			//Phase III
			/*
			 * update events with new notifications
			 * */
			for (String event : msg.events) {
				String event_id = generateID(event);
				if(!this.eventids.contains(event_id)) {
					//System.out.println("Node: " + this.id + " find an event:" + event_id + " from:" + msg.sender + " that isn't in his event ids and add it");
					this.events.add(event);
					this.eventids.add(event_id);
					}
				//DELIVER EVENT add the event to the list of delivered events
				if (!this.deliveredEvents.contains(event_id)) {
					this.deliveredEvents.add(event_id);
				}
			}
			
			for (String event_id : msg.eventids) {
				if(!this.eventids.contains(event_id)) {
					//if not contained -> generate an element to be retrieve 
					//System.out.println("Node: " + this.id + " receive a message from: " + msg.sender + " with event_id: " + event_id + " to retrieve");
					Element e = new Element(event_id, this.current_round, msg.sender);
				    this.retrive_buffer.add(e);
				}
			}
			
			while(this.eventids.size() > this.max_length_of_sub) {
				this.eventids.remove(0);
			}
			
			
			removeRandomEvents(this.events, this.max_length_of_sub);
			
			this.current_round++;
			//retrieve all message in the buffer
			this.retrive_event_notification();
		}
	}
	
	
	/*
	 * Method used to send a message to F neighbors is done once every round
	 * */
	@ScheduledMethod(start = 1, interval = 1)
	public void gossiping() {
		//only gossip if i'm sub
		if(this.state && !this.failed) {
			//add the id of the node if it is not contained yet 
			ArrayList<Integer>subs_plus_this = new ArrayList<Integer>(this.subs);
			if (!subs_plus_this.contains(this.id)) {
				subs_plus_this.add(this.id);
			}
			
			//check if the gossip message contain an event to track
			final Gossip_message gossip;
			
			if(this.event_to_track != "" && (this.events.contains(this.event_to_track) || this.eventids.contains(this.event_to_track))) {
				//send a track message if my events contains the target message
				//System.out.println("Node: " + this.id + " is sending a track msg with eventids: " + this.eventids.toString());
				//System.out.println("Node: " + this.id + " is sending a track msg with event: " + this.events.toString());
				
				gossip = new Gossip_message(
						new ArrayList<String>(this.events), 
						new ArrayList<String>(this.eventids), 
						new ArrayList<Integer>(this.un_subs), 
						new ArrayList<Integer>(subs_plus_this), 
						this.id, true, this.event_to_track);
			}
			else {
				//send a normal message 
				//construct a new gossip message create copies of the list to pass it as parameter and not as a reference
				//System.out.println("Node: " + this.id + " is sending a normal msg with eventids: " + this.eventids.toString());
				gossip = new Gossip_message(
						new ArrayList<String>(this.events), 
						new ArrayList<String>(this.eventids), 
						new ArrayList<Integer>(this.un_subs), 
						new ArrayList<Integer>(subs_plus_this), 
						this.id, false, "");
			}
		
			//get the network to add an edge from the gossip sender to the gossip receiver 
			Context <Object> context = ContextUtils.getContext(this);
			Network<Object> network_messagges = (Network<Object>)context.getProjection("network_messages");
			Network<Object> network_view = (Network<Object>)context.getProjection("network_view");
			
			//remove all edges to delete the previous gossiping messages from the simulation 
			removeAllExitEdges("network_messages");
			removeAllExitEdges("network_retrive");
			removeAllExitEdges("network_view");
			
			//show the new view
			for(int id : this.view) {
				network_view.addEdge(this, getNodeById(id));
			}
			
			//select random F neighbors and send the gossip message to all of them
			//this take the reference for the node using the view that contains only ids of nodes 
			ArrayList<Node> nodes = this.getNodesByIds(this.view);
			Collections.shuffle(nodes);
			
			//only for debug
			//ArrayList<Node> neigh = new ArrayList<Node>();
			
			for (int i = 0; i < this.F && i < this.view.size(); i++) {
				//send the gossip message to these neighbors get the nodes from the context and call the method on_gossip_receive
				Node target = nodes.get(i);
				//extract a value to simulate the probability to lose the message.
				if(!StdRandom.bernoulli(this.lose_msg_prob)) {
					target.on_gossip_receive(gossip);
					//add the edge to the network to use it in the representation 
					network_messagges.addEdge(this, target);
					//debug
					//neigh.add(target);
				}
			}
			/*
			String n="[";
			for(Node i : neigh) {
				n = n + i.id + ", ";
			}
			n = n +"]";
			//System.out.println(n);
			for(Node i : neigh) {
				i.on_gossip_receive(gossip);
			}*/
			
            //delete all events 
            this.events.clear();
            //generate a new event from this node with a given probability and add that event 
            //LPBCAST(e)

            //check if the total number of messages in the network N.B. static variable 
            if(StdRandom.bernoulli(this.gen_probability) & Node.network_messagges < Node.total_messagges ) {
                String message = "Message_"+this.id+ "_" + messageGenerated;
                //add the generated event to a list for retrieve it when somebody ask it to the source 
                this.generatedEvent.add(message);
                this.events.add(message);
                messageGenerated++;
                Node.network_messagges++;
            }

        current_round++;    
	   }
    }
	
	
	/*
	 * method used to retrieve an element used only to manage retransmission requests 
	 * */
	public void retrive_event_notification() {
		
		//only retrieve if i'm sub.
		if(this.state && !this.failed) {
			//get the network to add an edge from the retrieve sender to the retrieve receiver 
			Context <Object> context = ContextUtils.getContext(this);
			Network<Object> network_retrive = (Network<Object>)context.getProjection("network_retrive");
			
			
			
			ArrayList<Element> toBeRemoved = new ArrayList<Element>();
			for (Element el : retrive_buffer) {
				//debug 
				//System.out.println("Node: " + this.id + "try to retrive: " + el.getId());
				
				
				//round passed for the element 
				int passed_round = this.current_round-el.getRound();
				//check if i have that element now 
				if (!eventids.contains(el.getId())) {
					if(passed_round >= this.K && passed_round < this.R ) {
						//ask for the element to the gossip sender
						Node target = this.getNodeById(el.getSender());
						target.onRetrasmissionMessage(new Element(el), this.id);
						network_retrive.addEdge(this, target);
						return;
					}
					//second check if the element has been asked to a random node yet and waited for R round 
					if (passed_round >= this.R && passed_round < this.R * 2) {
						//ask the element to random node 
						int random = RandomHelper.nextIntFromTo(0,this.view.size() -1);
						int id = this.view.get(random);
						Node target = this.getNodeById(id);
						target.onRetrasmissionMessage(new Element(el), this.id);
						network_retrive.addEdge(this, target);
						return;
					}
					//first check if the element has been asked to a random node yet and waited for R round
					if (passed_round >= this.R * 2) {
						//ask the element to the source 
						Node target = this.getNodeById(el.getSource());
						target.onRetrasmissionMessage(new Element(el), this.id);
						network_retrive.addEdge(this, target);
						return;
					}
				} else {
					//add a list for removing element 
					toBeRemoved.add(el);
				}
			}
			current_round++;
			retrive_buffer.removeAll(toBeRemoved);
		}
	}
	
	
	/*
	 * method to handle retransmission request
	 * @param asked the element asked to me
	 * @param id_requester the id of who is making the request
	 */
	public void onRetrasmissionMessage(Element asked, int id_requester) {
		//only react if i'm sub
		if(this.state && !this.failed) {
			//check if i'm the source of the event 
			if (asked.getSource() == this.id) {
				String eventToGive = this.getEventsByIdFromList(this.generatedEvent, asked.getId());
				if(eventToGive != null) {
					this.getNodeById(id_requester).onRetrasmissionRecived(eventToGive, asked.getId());
				}
			} else if (this.events.contains(getEventsById(asked.getId()))) {
				String response = this.getEventsByIdFromList(this.events, asked.getId());
				if(response != null) {
					this.getNodeById(id_requester).onRetrasmissionRecived(response, asked.getId());
				}
			}
		}
	}
	
	/*
	 * method used when arrive a respond to a retransmission request 
	 * @param response boolean to see id the request is satisfied or not
	 * @param response_id the element id to be delivered id response was successful
	 */
	public void onRetrasmissionRecived(String response, String response_id) {
		//only react if i'm sub
		if(this.state && !this.failed) {
			if (!this.events.contains(response)) {
				events.add(response);
				eventids.add(response_id);
			}
			//LPBDELIVER(e)
			if (!this.deliveredEvents.contains(response_id)) {
				this.deliveredEvents.add(response_id);
				retrive_count++;
			}
		}
	}
	
	/*
	 * Method used to Subscribe to the topic
	 * */
	@ScheduledMethod(start = 2, interval = 5)
	public void subscribe() {
		if(!this.state && !this.failed) {
			//try to subscribe with sub_prb probability
			if(StdRandom.bernoulli(this.sub_prob)) {		
				//System.out.println("Node: " + this.id + " is making a sub");
				//System.out.println("Event: " + this.events.toString());
				//System.out.println("eventIDS: " + this.eventids.toString());
				//to subscribe i have to know a node from the net.
				//in order to simulate the procedure i just find a node randomly that is subscribe to the topic.
				Context <Object> context = ContextUtils.getContext(this);
				IndexedIterable <Object> nodes = context.getObjects(Node.class);
				Node t = null;
				int count_fail = 0;
				int count_unsub = 0;
				for(Object x : nodes) {
					Node e = (Node)x;
					if(e.failed) {
						count_fail++;
					}else if(!e.state) {
						count_unsub++;
					}else {
						//System.out.println("Node find ! --> " + e.id);
						t = e;
					}
				}
				
				if((count_fail + count_unsub) == nodes.size()) {
					//System.err.println("Nessuno nella rete di attivo.");
					RunEnvironment.getInstance().getCurrentSchedule().executeEndActions();
					RunEnvironment.getInstance().endRun();
					this.failed = true;
				}
					
				//once i find a node in the net i start gossip to him
				//add myself to the subs.
				ArrayList<Integer>subs_plus_this = new ArrayList<Integer>(this.subs);
				if (!subs_plus_this.contains(this.id)) {
					subs_plus_this.add(this.id);
				}
				if(t != null) {
					//add the target to my view to gossip
					this.view.add(t.getId());
				}
				
				
				//debug
				//System.out.println("UN_subs: " + this.un_subs);
				//System.out.println("subs+this: " + subs_plus_this);
				
				ArrayList<String> list = new ArrayList<String>(0);
				//create the gossip message
				final Gossip_message gossip = new Gossip_message(
						new ArrayList<String>(this.events), 
						new ArrayList<String>(list), 
						new ArrayList<Integer>(this.un_subs), 
						new ArrayList<Integer>(subs_plus_this), 
						this.id,
						false, 
						"");
					
				//send the message
				if(t != null) {
					t.on_gossip_receive(gossip);
				}
				
				//System.out.println("sent a message to: " + t.id + "with eids: " + this.eventids);
				removeAllExitEdges("network_sub");
				
				//add the edge to the network to use it in the representation 
				Network<Object> network_sub = (Network<Object>)context.getProjection("network_sub");
				if(t != null) {
					network_sub.addEdge(this, t);
					//and i set my state to (sub) because i want to respond if other messages arrives
					this.state = true;
					System.out.println("Node: " + this.id + " SUB");
				}
			}
		}
	}
	
	
	/*
	 * Method used to UNsubscribe to the topic
	 * */
	@ScheduledMethod(start = 3, interval = 5)
	public void un_subscribe() {
		if(this.state && !this.failed) {
			//try to unsubscribe with probability unsub_prob
			if(StdRandom.bernoulli(this.unsub_prob)) {
				
				System.out.println("Node: " + this.id + " UNSUB");
				//clear all buffers
				this.events.clear();
				this.eventids.clear();
				this.subs.clear();
				//this.un_subs.clear();
				this.retrive_buffer.clear();
				
				//send the goodbye message
				this.un_subs.add(this.id);
				
				Gossip_message gossip = new Gossip_message(
						new ArrayList<String>(this.events), 
						new ArrayList<String>(this.eventids), 
						new ArrayList<Integer>(this.un_subs), 
						new ArrayList<Integer>(this.subs), 
						this.id, false, "");
				
				ArrayList<Node> nodes = this.getNodesByIds(this.view);
				if(nodes.size() > 0) {
					for(Node node : nodes) {
						node.on_gossip_receive(gossip);
					}
				}
				
				//re-clear the unsub
				this.un_subs.clear();
				this.view.clear();
				
				//clear also variable
				this.generatedEvent.clear();
				this.event_to_track = "";
				//in order to un_sub i just give up gossiping and don't respond to anyone anymore
				//just set my state to --> unsub.
				this.state = false;
				
				removeAllExitEdges("network_messages");
				removeAllExitEdges("network_retrive");
				removeAllExitEdges("network_sub");
				removeAllExitEdges("network_view");
			}
		}
	}
	
	
	//remove the oldest unsuscribe to permit to the nodes to subscribe again 
	@ScheduledMethod(start = 3, interval = 20)
	private void removeOldUnsubscribe() {
		if(this.un_subs.size() > 0) {
			this.un_subs.remove(0);
		}
	}
	
	/**
	 * Method to truncate the list of subs/unsubs/view 
	 * @return ArrayList containing the elements removed form the list.
	 * */
	private ArrayList<String> removeRandomEvents (ArrayList<String> list, int max_size){
		Collections.shuffle(list);
		ArrayList<String> removed = new ArrayList<String>();
		
		for (int i = list.size()-1; i >= max_size; i--) {
			removed.add(list.get(i));
			list.remove(i);
		}
		return removed;
	}
	
	//same method but for list of type integer 
	private ArrayList<Integer> removeRandomElements (ArrayList<Integer> list, int max_size){
		Collections.shuffle(list);
		ArrayList<Integer> removed = new ArrayList<Integer>();
		
		for (int i = list.size()-1; i >= max_size; i--) {
			removed.add(list.get(i));
			list.remove(i);
		}
		return removed;
	}
	
	//methods to generate an ID for a event 
	private String generateID(String event) {
		return event;
	}
	
	//method to identify an event by his id 
	private String getEventsById(String eventID) {
		return eventID;
	}
	
	//method to get an event from a list using his id 
	private String getEventsByIdFromList(ArrayList<String> list, String id) {
		for (String event : list) {
			String eventID = getEventsById(event);
				if (eventID.equals(id)) {
					return event;
				}
			}
		return null;
	}
	
	//method to take all the nodes that correspond to a list of ids
	private ArrayList<Node> getNodesByIds (ArrayList<Integer> ids){
		Context <Object> context = ContextUtils.getContext(this);
		IndexedIterable <Object> nodes = context.getObjects(Node.class);
		ArrayList<Node> res = new ArrayList<Node>();
		for (Object n : nodes) {
			Node x = (Node) n;
			int id = x.getId();
			if (ids.contains(id)) {
				res.add(x);
			}
		}
		return res;
	}
	
	//method to get a single node from the list of all nodes using his id 
	private Node getNodeById (int id){
		Context <Object> context = ContextUtils.getContext(this);
		IndexedIterable <Object> nodes = context.getObjects(Node.class);
		
		for (Object n : nodes) {
			Node x = (Node) n;
			int target_id = x.getId();
			if (id == target_id) {
				return x;
			}
		}
		return null;
	}
	
	/*
	 * method used to generate a message to be tracked
	 * */
	public void generate_message_to_be_tracked() {
		if(!this.state || !this.failed) {
			String message = "Message_"+this.id+ "_" + messageGenerated;
	        //add the generated event to a list for retrieve it when somebody ask it to the source 
	        this.generatedEvent.add(message);
	        this.events.add(message);
	        messageGenerated++;
	        
	        this.infected = true;
	        this.event_to_track = message;
		}else {
			Node t;
			Context <Object> context = ContextUtils.getContext(this);
			do {
				//find a node that is subscribe and tell him to start a tracked message
				t = (Node)context.getRandomObject();
			}while(t.getFailed_b() || t.getState());
			t.generate_message_to_be_tracked();
		}
   	}
	
	/*
	 * method to simulate a failure on this node.
	 * */
	@ScheduledMethod(start = 3, interval = 5)
	public void failure() {
		if(!this.failed) {	
			if(StdRandom.bernoulli(this.failing_prob)) {
				this.failed = true;
				System.out.println("Node: " + this.id + " CRASH");
				removeAllExitEdges("network_messages");
				removeAllExitEdges("network_retrive");
				removeAllExitEdges("network_sub");
				removeAllExitEdges("network_view");
			}
		}
	}
	
	public int getFailed() {
		int i=0;
		if(this.failed){
			i = 1;
		}
		return i;
	}
	
	public boolean getFailed_b() {
		return this.failed;
	}
	
	//get the id of this node 
	public int getId () {
		return this.id;
	}
	
	public boolean getInfected_b() {
		return this.infected;
	}

	public int getInfected() {
		int i = 0;
		if(this.infected) {
			i = 1;
		}
		return i;
	}
	
	//remove all edges that exit from this node
	private void removeAllExitEdges (String network) {
		Context <Object> context = ContextUtils.getContext(this);
		Network<Object> network_messagges = (Network<Object>)context.getProjection(network);
		//remove all previous edges 
		ArrayList<RepastEdge<Object>> edges = new ArrayList<RepastEdge<Object>>();
		Iterable<RepastEdge<Object>>  edgesiter = network_messagges.getOutEdges(this);	
		for (RepastEdge<Object> edge : edgesiter) {
			edges.add(edge);
		}
		for (RepastEdge<Object> edge : edges) {
			network_messagges.removeEdge(edge);
		}
	}
	
	//find if the node have all the messages 
	public boolean hasAllMessagges() {
		return (this.deliveredEvents.size() == Node.total_messagges);
	}

	public boolean getState() {
		return this.state;
	}
}
