package DS2_Assignment_1;

public class Element {
	/*every retrieve request have to contain:
	 * (id, current_round, msg_sender) 
	 * where the id identify the event id that we want to retrieve
	 * the round at which the node that want to retrieve receive a message that cause him to retrive
	 * and the sender of the message that cause to retrieve
	 * */
	
	private String id;					//the id of the event to retrieve
	private int round;					//the round that cause the receiver to retrieve the message
	private int sender;					//the sender of the message that cause to retrieve
	private int source;     			//the generator of the message 
	private int first_ask_round = 0;	//used to save the round of the first ask for this element (sender node)
	private int second_ask_round = 0;	//used to save the round of the second ask for this element (random node) and finally ask to the source
	
	public Element(String id, int round, int sender) {
		this.id = id;
		this.round = round;
		this.sender = sender;
		this.source = Integer.parseInt(id.split("_")[1]);
	}
	public Element(Element el) {
		this.id = el.id;
		this.round = el.round;
		this.sender = el.sender;
		this.source = Integer.parseInt(el.id.split("_")[1]);
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getRound() {
		return round;
	}

	public void setRound(int round) {
		this.round = round;
	}

	public int getSender() {
		return sender;
	}

	public void setSender(int sender) {
		this.sender = sender;
	}
	public void setFirst_ask_round(int first_ask_round) {
		this.first_ask_round = first_ask_round;
	}
	public int getFirst_ask_round() {
		return first_ask_round;
	}

	public int getSecond_ask_round() {
		return second_ask_round;
	}

	public void setSecond_ask_round(int second_ask_round) {
		this.second_ask_round = second_ask_round;
	}

	public int getSource() {
		return source;
	}

	public void setSource(int source) {
		this.source = source;
	}
}
