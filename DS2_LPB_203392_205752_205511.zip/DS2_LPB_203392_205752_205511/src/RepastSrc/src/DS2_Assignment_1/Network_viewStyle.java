package DS2_Assignment_1;

import java.awt.Color;

import repast.simphony.space.graph.RepastEdge;
import repast.simphony.visualizationOGL2D.DefaultEdgeStyleOGL2D;

public class Network_viewStyle extends DefaultEdgeStyleOGL2D{
	@Override
	public Color getColor(RepastEdge<?> edge) {
		// TODO Auto-generated method stub
		return Color.cyan;
	}

	@Override
	public int getLineWidth(RepastEdge<?> edge) {
		// TODO Auto-generated method stub
		return 1;
	}
}
