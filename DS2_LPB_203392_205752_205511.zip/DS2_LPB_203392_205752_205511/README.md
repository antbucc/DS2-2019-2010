The file DS2_report.pdf includes the model of the system and a guide on how to use it to run simulations on Repast.

The jar file could be downloaded at: https://drive.google.com/drive/folders/1l4zYWGXCW669xBngLN3a2tHzJxQh_qfI?usp=sharing 